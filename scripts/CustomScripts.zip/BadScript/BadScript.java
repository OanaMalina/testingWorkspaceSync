import java.util.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

public class BadScript {    
    public static void main(String[] args){
        WebDriver driver;
        Map<String, Object> vars;
        JavascriptExecutor js;
    
        driver = new ChromeDriver();
        js = (JavascriptExecutor) driver;
        vars = new HashMap<String, Object>();
        
        driver.get("https://www.wikipedia.org/");
        driver.manage().window().setSize(new Dimension(1058, 812));
        driver.findElement(By.cssSelector("#js-link-box-it > strong")).click();
        driver.findElement(By.linkText("Discussione")).click();
        driver.findElement(By.cssSelector(".tocsection-13 .toctext")).click();
        
        driver.quit();
    }
}