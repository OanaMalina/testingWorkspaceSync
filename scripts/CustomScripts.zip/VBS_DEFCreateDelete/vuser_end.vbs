'"'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
'" Script Title       :
'"
'" Script Date        :
'"'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

Public Function Terminate()

    '" TO DO: Place your termination code here



    Terminate = lr.PASS
End Function
