'"'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
'" Script Title       : 
'" Script Description : 
'"                      
'"                      
'" Script Author      : 
'" Script Date        : 
'"'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

Public Function Init()

    '" TO DO: Place your initialization code here
	InitQC

	    Init = lr.PASS
End Function

public sub InitQC()
	'on Error resume next
    dim strCurrentOpenTransactionName 
	dim sServerName

    Set tdconnection = CreateObject("TDApiOle80.TDConnection.1")
	
	
	SetAttributes
	SelectProject
	SelectUserName
	lr.message "**************************  start test  ********************************************"
lr.save_string "shiftName", "swing"
lr.message lr.eval_string("{shiftName}")
	
	 
	lr.message  "print server " 
    dim s 
	s= GetAttribute("ServerName")
	lr.message "alm server:"+s
	lr.message "user:"+GetAttribute("UserName")
	lr.message "pw:"+DEFAULT_PASSWORD
	lr.message "project:"+GetAttribute("Project")
	lr.message "**************************    end test    *******************************************"
	
    strCurrentOpenTransactionName = "VB_T01_Login"
    lr.start_transaction strCurrentOpenTransactionName
		 
        tdconnection.InitConnection GetAttribute("ServerName"), "", ""
    lr.end_transaction strCurrentOpenTransactionName, lr.AUTO

    strCurrentOpenTransactionName = "VB_T02_ConnectProject"  
    lr.start_transaction strCurrentOpenTransactionName 
        tdconnection.ConnectProjectEx GetAttribute("ServerDomain"), GetAttribute("Project"), GetAttribute("UserName"), DEFAULT_PASSWORD
    lr.end_transaction strCurrentOpenTransactionName, lr.AUTO

	exit sub

'If Err.Number <> 0 Then
	'lr.end_transaction strCurrentOpenTransactionName, lr.FAIL
    'WScript.Echo "Error: " & Err.Number
    'WScript.Echo "Error (Hex): " & Hex(Err.Number)
    'WScript.Echo "Source: " &  Err.Source
    'WScript.Echo "Error in Login: " &  Err.Description
	'lr.error_message "Error in Login: " & Err.Description
    'Err.Clear
	'lr.abort
'End If
end sub	
