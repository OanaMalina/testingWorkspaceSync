'"'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
'" Script Title       :
'"
'" Script Date        :
'"'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

Public Function Action()

   dim bugID

    lr.think_time(10)
    bugID = AddDefect

	
    Action = lr.PASS
End Function

' AddDefect
'==========
public function AddDefect
'on error goto 1
    dim factory
    dim Bug1
    dim strCurrentOpenTransactionName

    set factory = tdconnection.BugFactory
    set Bug1 = factory.AddItem(Null)
    
    Bug1.Summary = "This is the description of an automatic created defect"
    Bug1.Field("BG_DESCRIPTION") = "This is the description of an automatic created defect" 
    Bug1.Status = "new"
    Bug1.Priority = "3-High"
    Bug1.Field("BG_SEVERITY") = "3-High"
    Bug1.DetectedBy = GetAttribute("UserName")
    Bug1.Field("BG_DETECTION_DATE") = Date

    strCurrentOpenTransactionName = "VB_DEF_CreateDeleteDefect_T01_AddDefect"    
    lr.start_transaction strCurrentOpenTransactionName
        Bug1.Post
    if Bug1.ID > 0 then
        lr.end_transaction strCurrentOpenTransactionName, lr.PASS
    else
        lr.end_transaction strCurrentOpenTransactionName, lr.FAIL
        lr.exit 2,1
    end if
    
    AddDefect = Bug1.ID

    set factory = nothing
    set Bug1 = nothing
    
    exit function

'ErrHandling:
'    lr.end_transaction strCurrentOpenTransactionName, lr.FAIL
'    lr.error_message "Error in AddDefect: " + Err.Description
end function

' DeleteDefect
'=============
public sub DeleteDefect(bugID)
'on error goto ErrHandling
    dim factory
    dim strCurrentOpenTransactionName

    set factory = tdconnection.BugFactory

    strCurrentOpenTransactionName = "VB_DEF_CreateDeleteDefect_T03_DeleteDefect"    
        lr.start_transaction strCurrentOpenTransactionName        
        factory.RemoveItem (bugID)
    lr.end_transaction strCurrentOpenTransactionName, lr.PASS

    set factory = nothing
    exit sub

'ErrHandling:
'    lr.end_transaction strCurrentOpenTransactionName, lr.FAIL
'    lr.error_message "Error in DeleteDefect: Failed to Delete BUG ID : " & Cstr(bugID) + ": " + Err.Description
end sub

' UpdateDefect
'=============
public sub UpdateDefect(bugId)
'on error goto ErrHandling
    dim factory
    dim Bug1
    dim strCurrentOpenTransactionName
    
    set factory = tdconnection.BugFactory
    set Bug1 = factory.Item(bugID)
    
    Bug1.Field("BG_USER_01") = GetAttribute("Value1")

    strCurrentOpenTransactionName = "VB_DEF_CreateDeleteDefect_T02_UpdateDefect"    
    lr.start_transaction strCurrentOpenTransactionName        
        Bug1.Post
    lr.end_transaction strCurrentOpenTransactionName, lr.PASS

    set factory = nothing
    set Bug1 = nothing

	 exit sub
'ErrHandling:
'    lr.end_transaction strCurrentOpenTransactionName, lr.FAIL
'    lr.error_message "Error in UpdateDefect: Failed to Update BUG ID : " & Cstr(bugID) + ": " + Err.Description
end sub

' GetDefectsList
'===============
public sub GetDefectsList
'on error goto ErrHandling
    dim factory
    dim objFilter
    dim objList
    dim strCurrentOpenTransactionName
    
    lr.start_transaction "Get Defects list"
        set factory = tdconnection.BugFactory
        set objFilter = factory.Filter
        set objList = factory.NewList(objFilter.Text)
    lr.end_transaction "Get Defects list", lr.PASS

    set factory = nothing
    set objFilter = nothing
    set objList = nothing

	exit sub
'ErrHandling:
'    lr.end_transaction strCurrentOpenTransactionName, lr.FAIL
'    lr.error_message "Error in GetDefectsList: " + Err.Description
end sub