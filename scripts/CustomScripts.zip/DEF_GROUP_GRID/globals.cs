//---------------------------------------------
//Script Title        :
//Script Description  :
//
//
//Recorder Version    : 1982
//---------------------------------------------

namespace Script {
    using LoadRunner;
    using Mercury.LoadRunner.DotNetProtocol.Replay;
    using System;
    using TDAPIOLELib;
    
    public partial class VuserClass {

        TDConnection tdconnection;
        Random rnd = new Random(Guid.NewGuid().GetHashCode());

        const int DEPTH = 5;
        const int STEPS_PER_TEST = 10;
        const int VERSIONS_NUMBER_PER_TEST = 5;
        const int DEFECTS_PER_VUSER = 300;
        const int NUMBER_DEFECTS_PER_FILTER = 350;
        const int USERS_FIRST = 2;
        const int USERS_TOTAL = 3000;
        const string DEFAULT_PASSWORD = "";
        const int NUMBER_OF_REQUIREMENTS = 30;
        const string DEFAULT_PROJECT_PREFIX = "MASTERDB";

        // default command line attributes
        const String DEFAULT_USERNAME_PREFIX = "admin";
        const int DEFAULT_TOTAL_VUSERS = 200;
        const int DEFAULT_PROJECT_FIRST = 1;
        const int DEFAULT_PROJECTS_TOTAL = 10;
        const int DEFAULT_PROJECTS_MAIN = 4;
        const int DEFAULT_PROJ_MAIN_LOAD = 7;
        const String DEFAULT_DOMAIN = "DEFAULT";
        const String DEFAULT_REPOSITORY_TYPE = "logical"; //physical;
        const String DEFAULT_FILE_TYPE = "multi"; //'single;
        const String DEFAULT_ENABLE_DELETE = "TRUE";
        const String DEFAULT_SSO = "N";

        public String getAttribute(String str_attribute_name)
        {
            if (!String.IsNullOrEmpty(str_attribute_name))
            {
                return lr.eval_string("{" + str_attribute_name + "}");
            }
            else
            {
                lr.error_message("Fail to get attribute:" + str_attribute_name);
                return "";
            }
        }

        public void setAttributes()
        {
            string str_server_name;
            string str_domain;
            string str_project_first;
            string str_project_totals;
            string str_main_projects;
            string str_project_name;
            string str_main_projects_load;
            string str_vusers;
            string str_repostiory_type;
            string str_file_type;
            string str_user_name;
            string enable_delete;
            string str_password;
            string str_sso;

            str_server_name = lr.get_attrib_string("ServerName");
            if (!String.IsNullOrEmpty(str_server_name))
            {
                lr.save_string("ServerName", str_server_name);
            }
            else
            {
                lr.error_message("ServerName cannot be empty. Please add it to Command Line or Attributes.");
            }

            str_domain = lr.get_attrib_string("Domain");
            lr.save_string("Domain", String.IsNullOrEmpty(str_domain) ? DEFAULT_DOMAIN : str_domain);

            //lr.save_string("Domain", str_domain == "" ? DEFAULT_DOMAIN : str_domain);

            str_project_first = lr.get_attrib_string("ProjectFirst");
            lr.save_string("ProjectFirst", String.IsNullOrEmpty(str_project_first) ? DEFAULT_PROJECT_FIRST.ToString() : str_project_first);

            str_project_name = lr.get_attrib_string("ProjectName");
            lr.save_string("ProjectName", String.IsNullOrEmpty(str_project_name) ? "" : str_project_name);

            str_project_totals = lr.get_attrib_string("ProjectTotal");
            lr.save_string("ProjectTotal", String.IsNullOrEmpty(str_project_totals) ? DEFAULT_PROJECTS_TOTAL.ToString() : str_project_totals);

            str_main_projects = lr.get_attrib_string("MainProjects");
            lr.save_string("MainProjects", String.IsNullOrEmpty(str_main_projects) ? DEFAULT_PROJECTS_MAIN.ToString() : str_main_projects);

            str_main_projects_load = lr.get_attrib_string("MainProjectsLoad");
            lr.save_string("MainProjectsLoad", String.IsNullOrEmpty(str_main_projects_load) ? DEFAULT_PROJ_MAIN_LOAD.ToString() : str_main_projects_load);

            str_repostiory_type = lr.get_attrib_string("RepositoryType");
            lr.save_string("RepositoryType", String.IsNullOrEmpty(str_repostiory_type) ? DEFAULT_REPOSITORY_TYPE : str_repostiory_type);

            str_file_type = lr.get_attrib_string("FileType");
            lr.save_string("FileType", String.IsNullOrEmpty(str_file_type) ? DEFAULT_FILE_TYPE : str_file_type);

            enable_delete = lr.get_attrib_string("EnableDelete");
            lr.save_string("EnableDelete", String.IsNullOrEmpty(enable_delete) ? DEFAULT_ENABLE_DELETE : enable_delete);

            str_user_name = lr.get_attrib_string("UserName");
            lr.save_string("UserName", String.IsNullOrEmpty(str_user_name) ? DEFAULT_USERNAME_PREFIX : str_user_name);

            str_password = lr.get_attrib_string("Password");
            lr.save_string("Password", String.IsNullOrEmpty(str_password) ? DEFAULT_PASSWORD : str_password);

            str_sso = lr.get_attrib_string("SSO");
            lr.save_string("SSO", String.IsNullOrEmpty(str_sso) ? DEFAULT_SSO : str_sso);

            str_vusers = lr.get_attrib_string("VusersCount");
            lr.save_string("VusersCount", String.IsNullOrEmpty(str_vusers) ? DEFAULT_TOTAL_VUSERS.ToString() : str_vusers);

            lr.message(lr.eval_string("ServerName = {ServerName}"));
            lr.message(lr.eval_string("ProjectFirst = {ProjectFirst}"));
            lr.message(lr.eval_string("ProjectName = {ProjectName}"));
            lr.message(lr.eval_string("ProjectTotal = {ProjectTotal}"));
            lr.message(lr.eval_string("MainProjects = {MainProjects}"));
            lr.message(lr.eval_string("MainProjectsLoad = {MainProjectsLoad}"));
            lr.message(lr.eval_string("RepositoryType = {RepositoryType}"));
            lr.message(lr.eval_string("FileType = {FileType}"));
            lr.message(lr.eval_string("EnableDelete = {EnableDelete}"));
            lr.message(lr.eval_string("VusersCount = {VusersCount}"));

        }

        /// <summary>
        /// Select a Vuser randomly
        /// </summary>
        public void selectUserName()
        {
            String str_user_name;
            String str_user_prefix;
            int i_user_index;
            str_user_prefix = getAttribute("UserName");
            i_user_index = rnd.Next(1, USERS_TOTAL + 1);

            if (str_user_prefix.Contains("@"))
            {
                String[] user = str_user_prefix.Split('@');
                str_user_name = user[0] + str_user_prefix.ToString() + "@" + user[1];
            }
            else
            {
                str_user_name = str_user_prefix + i_user_index;
            }

            lr.save_string("UserName", str_user_name);

            lr.message(lr.eval_string("UserName = {UserName}"));
        }


        //TODO: 
        public void selectProject()
        {
            int nProjectIndex;
            int nVuserUniqueKey;
            int nFirstProject;
            int nMainProjects;
            int nMainLoad;
            int nTotalProjects;
            int possibility;

            if (!String.IsNullOrEmpty(getAttribute("ProjectName")))
            {
                lr.save_string("Project", getAttribute("ProjectName"));
            }
            else
            {
                nVuserUniqueKey = lr.eval_int("{VuserUniqueKey}");
                nVuserUniqueKey = nVuserUniqueKey > 100 ? nVuserUniqueKey / 100 : nVuserUniqueKey;
                possibility = (nVuserUniqueKey - 1) % 10;//Key is from 0-9
                nFirstProject = lr.eval_int("{ProjectFirst}");
                nMainProjects = lr.eval_int("{MainProjects}");
                nTotalProjects = lr.eval_int("{ProjectTotal}");
                nMainLoad = lr.eval_int("{MainProjectsLoad}");

                if (nFirstProject < 1 || nFirstProject > nTotalProjects)
                {
                    lr.error_message("ProjectFirst should be >1 and <ProjectTotal. value=" + nFirstProject);
                    lr.exit(lr.EXIT_VUSER, lr.FAIL);
                }
                else if (nTotalProjects < 1)
                {
                    lr.error_message("ProjectTotal cannot be non positive. value=" + nTotalProjects);
                    lr.exit(lr.EXIT_VUSER, lr.FAIL);
                }
                else if (nMainProjects < 0)
                {
                    lr.error_message("MainProjects cannot be negative. value=" + nMainProjects);
                    lr.exit(lr.EXIT_VUSER, lr.FAIL);
                }
                else if (nTotalProjects < nMainProjects)
                {
                    lr.error_message("ProjectTotal cannot be lower than MainProjects. value=" + nTotalProjects);
                    lr.exit(lr.EXIT_VUSER, lr.FAIL);
                }
                else if (nMainLoad < 0 || nMainLoad > 10)
                {
                    lr.error_message("PMainProjectsLoad must be between 0 and 10. value =" + nMainLoad);
                    lr.exit(lr.EXIT_VUSER, lr.FAIL);
                }
                int nIteration = (nVuserUniqueKey - 1) / 10;
                int nOtherCount = nIteration * (10 - nMainLoad);
                int nMainCount = nIteration * nMainLoad + nMainLoad;

                if (nMainProjects == 0 || nMainProjects >= nTotalProjects)
                {
                    //Pick projects sequentially
                    nProjectIndex = (nVuserUniqueKey - 1) % 10 + nFirstProject;
                }
                else
                {
                    if (possibility < nMainLoad)
                    {
                        nProjectIndex = ((nVuserUniqueKey - nOtherCount - 1) % nMainProjects) + nFirstProject;
                        lr.message("Selecting Main Project:" + nProjectIndex);
                    }
                    else
                    {
                        nProjectIndex = ((nVuserUniqueKey - nMainCount - 1) % (nTotalProjects - nMainProjects)) + (nFirstProject + nMainProjects);
                        lr.message("Selecting Remain Project:" + nProjectIndex);
                    }
                }
                lr.save_string("Project", DEFAULT_PROJECT_PREFIX + nProjectIndex);
                lr.message(lr.eval_string("Project {Project} wselected for VuserUniqueKey {VuserUniqueKey}"));
            }

            //If main projects

        }


        public void generateUniqueString(String str_param_name, String str_basic_string, String str_join_char) {
            String str_vuser_ID;
            String str_group_name;
            String str_time_now;
            String str_final_string;

            str_vuser_ID = getAttribute("VuserID");
            str_time_now = getAttribute("CurrentDateTime");
            str_group_name = getAttribute("GroupName");

            str_final_string = str_basic_string + str_join_char + str_vuser_ID + str_join_char + str_group_name + str_join_char + str_time_now;
            lr.save_string(str_param_name, str_final_string);


        }


        public void dynamicTransactionName(String str_trfname, String str_trchange, String str_trlname, String str_param_name, String str_out_param_name) {
            lr.save_string(str_out_param_name, str_param_name.Contains("Y") ? str_trfname + str_trlname + str_trchange : str_trfname + str_trlname);
        }

    }
}
