//---------------------------------------------
//Script Title        :
//Script Description  :
//
//
//Recorder Version    : 1982
//---------------------------------------------

namespace Script {
    using LoadRunner;
    using Mercury.LoadRunner.DotNetProtocol.Replay;
    using System;
    using TDAPIOLELib;

    public partial class VuserClass {

        string[] strFieldName = new string[2];
    	
        public int Action() {
            lr.think_time(10);
            getDefectsByFilterAndGrouped();

            return 0;
        }

    	public void getDefectsByFilterAndGrouped(){
            IBugFactory ibugfact = tdconnection.BugFactory;
            ITDFilter ifilter = ibugfact.Filter;
            IGroupingManager gm = ((IBaseFactory2)ibugfact).GroupingManager;

            fillData(ifilter);
            ((ISupportFetchLimit)ifilter).FetchLimit = 500;
            gm.Group[strFieldName[0]] = 1;
            gm.Group[strFieldName[1]] = 2;
            gm.Filter = ifilter;

            strCurrentOpenTransactionName = "DEF_GroupGrid_T01_GroupingFilter";
            lr.start_transaction(strCurrentOpenTransactionName);
            gm.Refresh();
            lr.end_transaction(strCurrentOpenTransactionName, lr.AUTO);

        }
    	
    	public void fillData(ITDFilter ifilter){
    		
    		string[] datalist;
    		string strFieldData;
    		int pos;
    		
    		for (int i=0;i<lr.eval_int("{sCount}");i++){
    			strFieldName[i]=lr.eval_string("{Label}");
    			strFieldData = lr.eval_string("{sData}");
    			datalist = strFieldData.Split(';');

				if(strFieldData.Length>0){
					pos = rnd.Next(0, datalist.Length);
					strFieldData=datalist[pos];
                    lr.output_message("Setting filter field:" + strFieldName[i] + " with value:" + strFieldData);
                } else{
    				lr.output_message("No data available");
    			}
                /*(if (strFieldName.Contains("_USER_")){
                    pos = rnd.Next(0, datalist.Length);
                    strudf1 = datalist[pos];
                    while (strudf1.Contains(strFieldData))
                    {
                        pos = rnd.Next(0, datalist.Length);
                        strudf1 = datalist[pos];
                    }
                    strFieldData= "\"" + strFieldData + "\"" + " Or " + "\"" + strudf1 + "\"";
                }*/
                ifilter[strFieldName[i]]="\""+strFieldData+"\"";
            }
    	}

    }
}
