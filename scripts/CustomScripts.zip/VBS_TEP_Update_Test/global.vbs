'"'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
'" Global Section       : 
'"  List of global variables and objects.
'" 
'" Scripting References : 
'"    http://msdn.microsoft.com/scripting/default.htm
'" 
'"'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''



'" Standard LoadRunner Objects.......................................
Set lr = CreateObject("LoadRunner.LrApi")                           '" LoadRunner API Object  
'Set web = CreateObject("LoadRunner.WebApi")                        '" LR Web API Object <Optional>
Set objectHelper = CreateObject("LoadRunnerVbs.ObjectFactory")      '" LR Object Factory Helper
Set recordsetHelper = CreateObject("LoadRunnerVbs.RecordSetHelper") '" LR recordset Helper
'"Application's Global Objects/Variables............................
'
' Example: Dim myserver 
'          Dim myvar
'          Dim myarray()

'Option Explicit
'
dim isVCProject             
dim tdconnection            
dim objRecordset            
dim objSubjectNode          
dim bugsList                
dim ReqListFromRoot         
dim childList               
dim testSetList             
dim parent                  
dim nCountFilteredBugs      
dim nRandomBugSelect        
dim sBgComments             
dim sBgDescription          
dim sBgSummary              
dim nReqCount               
dim sParentReqPath          
dim nCountFilteredFolders   

'dim strPrefixName string 'USED BY??

const DEPTH                     = 5
const STEPS_PER_TEST            = 10
const VERSIONS_NUMBER_PER_TEST  = 5
const DEFECTS_PER_VUSER         = 300
const NUMBER_DEFECTS_PER_FILTER = 350
const USERS_FIRST               = 1
const USERS_TOTAL               = 3000
const DEFAULT_PASSWORD          = ""
const NUMBER_OF_REQUIREMENTS    = 30
const DEFAULT_PROJECT_PREFIX    = "MASTERDB"

' default command line attributes
const DEFAULT_USERNAME_PREFIX = "admin"
const DEFAULT_TOTAL_VUSERS    = 200
const DEFAULT_PROJECT_FIRST   =  1
const DEFAULT_PROJECTS_TOTAL  = 10
const DEFAULT_PROJECTS_MAIN   = 4
const DEFAULT_PROJ_MAIN_LOAD  = 7
const DEFAULT_DOMAIN          = "DEFAULT"
const DEFAULT_REPOSITORY_TYPE = "logical" 'physical
const DEFAULT_FILE_TYPE       = "multi" 'single
const DEFAULT_ENABLE_DELETE   = "TRUE" 'FALSE

' IIF
'====
public function IIF(Expression, TruePart, FalsePart)
	If Expression = True Then
		If IsObject(TruePart) Then
			Set IIF = TruePart
		Else
			IIF = TruePart
		End If
	Else
		If IsObject(FalsePart) Then
			Set IIF = FalsePart
		Else
			IIF = FalsePart
		End If
	End If
End Function
		
' GetAttribute
'=============
public function GetAttribute(pAttribName ) 
	on Error resume next
    if pAttribName <> "" then
        GetAttribute = lr.eval_string("{"+pAttribName+"}")
    else
        Err.Description = "pAttribName cannot be empty"
    end if
    
    exit function
If Err.Number <> 0 Then
    WScript.Echo "Error: " & Err.Number
    WScript.Echo "Error (Hex): " & Hex(Err.Number)
    WScript.Echo "Source: " &  Err.Source
    WScript.Echo "Description: " &  Err.Description
    Err.Clear
	lr.abort
end If
end function

' SetAttributes
'==============
public sub SetAttributes
on Error resume next
    dim sServerName 
    dim sDomain 
    dim sProjectFirst 
    dim sProjectTotal 
    dim sMainProjects 
    dim sProjectName 
    dim sMainProjectsLoad 
    dim sVusers 
    dim sRepositoryType 
    dim sFileType 

	sServerName = lr.get_attrib_string("ServerName")
	if sServerName <> "" then
    	lr.save_string "ServerName", sServerName
    else
        Err.Description = "ServerName cannot be empty. Please add it to Command Line or Attributes"        
    end if
    
    sDomain = lr.get_attrib_string("Domain")
			lr.save_string "ServerDomain", IIF(sDomain <> "", sDomain, DEFAULT_DOMAIN)
	
	sProjectFirst = lr.get_attrib_string("ProjectFirst")
			lr.save_string "ProjectFirst", IIF(sProjectFirst <> "", sProjectFirst, DEFAULT_PROJECT_FIRST)
    
    sProjectName = lr.get_attrib_string("ProjectName")
    		lr.save_string "ProjectName", IIF(sProjectName <> "", sProjectName, "")
    
    sProjectTotal = lr.get_attrib_string("ProjectTotal")
    		lr.save_string "ProjectTotal", IIF(sProjectTotal <> "", sProjectTotal, DEFAULT_PROJECTS_TOTAL)
    
    sMainProjects = lr.get_attrib_string("MainProjects")
    		lr.save_string "MainProjects", IIF(sMainProjects <> "", sMainProjects, DEFAULT_PROJECTS_MAIN)
    
    sMainProjectsLoad = lr.get_attrib_string("MainProjectsLoad")
    		lr.save_string "MainProjectsLoad", IIF(sMainProjectsLoad <> "", sMainProjectsLoad, DEFAULT_PROJ_MAIN_LOAD)

    sRepositoryType = lr.get_attrib_string ("RepositoryType")
    		lr.save_string "RepositoryType", IIF(sRepositoryType <> "", sRepositoryType, DEFAULT_REPOSITORY_TYPE)
    
    sFileType = lr.get_attrib_string ("FileType")
    		lr.save_string "FileType", IIF(sFileType <> "", sFileType, DEFAULT_FILE_TYPE)

    sFileType = lr.get_attrib_string ("EnableDelete")
    		lr.save_string "EnableDelete", IIF(sFileType <> "", sFileType, DEFAULT_ENABLE_DELETE)
    
    sVusers = lr.get_attrib_string ("Vusers#")
    		lr.save_string "Vusers#", IIF(sVusers <> "", sVusers, DEFAULT_TOTAL_VUSERS)

	lr.message lr.eval_string("ServerName = {ServerName}")
    lr.message lr.eval_string("ProjectFirst = {ProjectFirst}")
    lr.message lr.eval_string("ProjectName = {ProjectName}")
    lr.message lr.eval_string("ProjectTotal = {ProjectTotal}")
    lr.message lr.eval_string("MainProjects = {MainProjects}")
    lr.message lr.eval_string("MainProjectsLoad = {MainProjectsLoad}")
    lr.message lr.eval_string("RepositoryType = {RepositoryType}")
    lr.message lr.eval_string("FileType = {FileType}")
    lr.message lr.eval_string("EnableDelete = {EnableDelete}")
    lr.message lr.eval_string("Vusers# = {Vusers#}")
    
    exit sub

If Err.Number <> 0 Then
    WScript.Echo "Error: " & Err.Number
    WScript.Echo "Error (Hex): " & Hex(Err.Number)
    WScript.Echo "Source: " &  Err.Source
    WScript.Echo "Description: " &  Err.Description
    Err.Clear
	lr.abort
end If
end sub

' SelectUserName
'===============
public sub SelectUserName
on Error resume next
    dim nUserIndex 
    dim sUserName 

    Randomize
    nUserIndex = CLng((USERS_TOTAL - USERS_FIRST) * Rnd) + USERS_FIRST
    sUserName = DEFAULT_USERNAME_PREFIX + Cstr(nUserIndex)

	sUserNameT = lr.get_attrib_string ("UserName")
    		lr.save_string "UserName", IIF(sUserNameT <> "", sUserNameT, sUserName)
    	'lr.save_string "UserName", sUserName
    lr.message lr.eval_string("UserName = {UserName}")

    exit sub

If Err.Number <> 0 Then
    WScript.Echo "Error: " & Err.Number
    WScript.Echo "Error (Hex): " & Hex(Err.Number)
    WScript.Echo "Source: " &  Err.Source
    WScript.Echo "Error in SelectUserName: " &  Err.Description
	lr.error_message "Error in SelectUserName: " + Err.Description
    Err.Clear
	lr.abort
end If
end sub

' SelectProject
'==============
public sub SelectProject
on Error resume next
    dim nVuserUniqueKey 
    dim nProjectIndex 
    dim nFirstProject 
    dim nMainProjects 
    dim nMainProjectsLoad 
    dim nTotalProjects 
    dim nIteration 
    dim nMainCount 
    dim nOtherCount 
    dim nBASe10Key 

    ' if a project wspecified exit the function
    if GetAttribute("ProjectName") <> "" then
    	lr.save_string "Project", GetAttribute("ProjectName")
        exit sub
    end if
	
	nFirstProject = Clng(GetAttribute("ProjectFirst"))
    nMainProjects = Clng(GetAttribute("MainProjects"))
    nTotalProjects = Clng(GetAttribute("ProjectTotal"))
    nMainProjectsLoad = Clng(GetAttribute("MainProjectsLoad"))
	
    if  nMainProjects > 0 and nMainProjects < nTotalProjects then
	 if Clng(GetAttribute("VuserUniqueKey"))>100 then
		 nVuserUniqueKey = Clng(GetAttribute("VuserUniqueKey"))/100
     end if
   	else
		 nVuserUniqueKey = Clng(GetAttribute("VuserUniqueKey"))
	 end if    


    ' verify values
    if nFirstProject < 1 or nFirstProject > nTotalProjects then
        Err.Description = "ProjectFirst is invalid. value = "+CStr(nFirstProject)
        
    elseif nTotalProjects < 1 then
        Err.Description = "ProjectTotal cannot non positive. value = "+CStr(nTotalProjects)
        
    elseif nMainProjects < 0 then
        Err.Description = "MainProjects cannot be negative. value = "+CStr(nMainProjects)
        
    elseif nTotalProjects < nFirstProject or nTotalProjects < nMainProjects then
        Err.Description = "ProjectTotal cannot be lower than ProjectFirst or MainProjects. value = "+CStr(nTotalProjects)
        
    elseif nMainProjectsLoad < 0 or nMainProjectsLoad > 10 then
        Err.Description = "MainProjectsLoad must be between 0 and 10. value = "+CStr(nMainProjectsLoad)
        
    end if
    
    ' formula variables
    nBASe10Key = (nVuserUniqueKey-1) mod 10 'key from 0-9
    nIteration = Int((nVuserUniqueKey-1)/10)
    nOtherCount = nIteration*(10-nMainProjectsLoad)
    nMainCount = nIteration*nMainProjectsLoad + nMainProjectsLoad
    
    ' decide how to generate project numbers
    if nMainProjects >= nTotalProjects or nMainProjects = 0 then
        ' pick projects sequentially
        nProjectIndex = ((nVuserUniqueKey-1) mod nTotalProjects) + nFirstProject
    else
        ' pick correct formula
        if (nBASe10Key < nMainProjectsLoad) then
            ' use main projects
            nProjectIndex = ((nVuserUniqueKey-nOtherCount-1) mod nMainProjects) + nFirstProject
        else
            ' use rest of projects
            nProjectIndex = ((nVuserUniqueKey-nMainCount-1) mod (nTotalProjects-nMainProjects)) + (nFirstProject+nMainProjects)
        end if
    end if
    
    lr.save_string "Project", Cstr(DEFAULT_PROJECT_PREFIX) + Cstr(nProjectIndex)
    lr.message lr.eval_string("Project {Project} wselected for VuserUniqueKey {VuserUniqueKey}")
    
    exit sub

If Err.Number <> 0 Then
    WScript.Echo "Error: " & Err.Number
    WScript.Echo "Error (Hex): " & Hex(Err.Number)
    WScript.Echo "Source: " &  Err.Source
    WScript.Echo "Error in SelectProject: " &  Err.Description
	lr.error_message "Error in SelectProject: " & Err.Description
    Err.Clear
	lr.abort
end If
end sub

' GenerateUniqueString
'=====================
public sub GenerateUniqueString (sOutputParamName , sBasicString , sConnectionCharacter )
on Error resume next
    dim sVUser_ID 
    dim sGroupName 
    dim sOutputBuffer 
    dim GenerateUniqueString_TimeNow 

    sVUser_ID = GetAttribute("VuserID") 'lr.eval_string("{VuserID}")
    GenerateUniqueString_TimeNow = GetAttribute("CurrentDateTime") 'lr.eval_string("{CurrentDateTime}")
    sGroupName = GetAttribute("GroupName") 'lr.eval_string("{GroupName}")
    
    sOutputBuffer = sBasicString + sConnectionCharacter + sVUser_ID + sConnectionCharacter + sGroupName + sConnectionCharacter + GenerateUniqueString_TimeNow

    lr.save_string sOutputParamName, sOutputBuffer

    exit sub
    
If Err.Number <> 0 Then
    WScript.Echo "Error: " & Err.Number
    WScript.Echo "Error (Hex): " & Hex(Err.Number)
    WScript.Echo "Source: " &  Err.Source
    WScript.Echo "Error in GenerateUniqueString: " &  Err.Description
    lr.error_message "Error in GenerateUniqueString: " & Err.Description
    Err.Clear
	lr.abort
end If
end sub

' DynamicTRname
'==============
public sub DynamicTRname(sTRFname , sTRchange , sTRLname , sParamName , sOutParamName )
on Error resume next
    lr.save_string sOutParamName, IIF(instr(sParamName,"Y"), sTRFname + sTRLname + sTRchange, sTRFname + sTRLname)
    exit sub

If Err.Number <> 0 Then
    WScript.Echo "Error: " & Err.Number
    WScript.Echo "Error (Hex): " & Hex(Err.Number)
    WScript.Echo "Source: " &  Err.Source
    WScript.Echo "Error in DynamicTRname: " &  Err.Description
    lr.error_message "Error in DynamicTRname: " & Err.Description
    Err.Clear
	lr.abort
end If
end sub

' subSetRequirementRecordSet
'===========================
' Creating List of IDs for Reqs to recieve Coverage
Private sub subSetRequirementRecordSet
on Error resume next
    dim objCommand 'TDAPIOLELib.Command
    
    set objCommand = tdconnection.Command
    objCommand.CommandText = "SELECT rq_req_id, rq_req_path FROM REQ where rq_req_path like '______'  or rq_req_path like '___'"
    set objRecordset = objCommand.Execute
    set objCommand = Nothing

    exit sub
    
If Err.Number <> 0 Then
    WScript.Echo "Error: " & Err.Number
    WScript.Echo "Error (Hex): " & Hex(Err.Number)
    WScript.Echo "Source: " &  Err.Source
    WScript.Echo "Error in subSetRequirementRecordSet: " &  Err.Description
    lr.error_message "Error in subSetRequirementRecordSet: " & Err.Description
    Err.Clear
	lr.abort
end If
end sub


' subSetReqId_ReqPath
'====================
' function Sets randomly ReqPath and appropriate ReqID for Coverage Filter
Private sub subSetReqId_ReqPath(byRef sReqId  , byRef sReqPath  , byRef sReqList )
on error resume next
    dim nTotalReqsInList 
    dim nItem 

    nTotalReqsInList = CLng(objRecordset.RecordCount)

    if nTotalReqsInList=0 then
        Err.Description = "There is a problem with Req Root Tree, there is 0 Items found... exiting"
    end if

    Randomize
    nItem = CLng(nTotalReqsInList * Rnd()) + 1
    objRecordset.Position = nItem

    sReqId = CStr(objRecordset.FieldValue(0))
    sReqPath = CStr(objRecordset.FieldValue(1))

    sReqList = ""
    for nItem=0 to nTotalReqsInList-1 ' -1 is added since the last member of set is added twice to sReqList
        objRecordset.Position = nItem
        sReqList = sReqList + CStr(objRecordset.FieldValue(0))
        if nItem< (nTotalReqsInList-1 ) then sReqList = sReqList + "," 
    next 
    	lr.output_message(" Total Reqs In List: " + Cstr(nTotalReqsInList))
    	lr.output_message(" Total Reqs In List: " + Cstr(nTotalReqsInList))
    	lr.output_message(" Random sReqId: " + Cstr(sReqId))
    	lr.output_message(" Random sReqPath: " + Cstr(sReqPath))
    	lr.output_message(" sReqList: " + Cstr(sReqList))

    exit sub
    
If Err.Number <> 0 Then
    WScript.Echo "Error: " & Err.Number
    WScript.Echo "Error (Hex): " & Hex(Err.Number)
    WScript.Echo "Source: " &  Err.Source
    WScript.Echo "Error in subSetReqId_ReqPath: " &  Err.Description
    lr.error_message "Error in subSetReqId_ReqPath: " & Err.Description
    Err.Clear
	lr.abort
end If
end sub

'' subMinMaxTestIDRecSetPerVuser
''==============================
Private sub subMinMaxTestIDRecSetPerVuser(byref nMinItemInObjectsList , byref nMaxItemInObjectsList )
on error resume next
    dim nTotalObjectsPerVuser 
    dim nCurrVUserID  'Contains the ID (number, index)  of current VUser
    dim nTotalTestsInList 
    dim nRemainder 
    dim nMin , nMax 
    dim objCommand 'TDAPIOLELib.Command

    set objCommand = tdconnection.Command
    objCommand.CommandText = "SELECT TS_TEST_ID FROM TEST WHERE TS_VC_STATUS='Checked_In' OR ts_vc_status is null and TS_TYPE = 'MANUAL'" '"select TS_TEST_ID from test where TS_NAME like 'Test%Subject%' and TS_VC_STATUS='Checked_In'"
    set objRecordset = objCommand.Execute

    'nCurrVUserID=CInt(lr.vuser_id) - didnt work correctly under VUgen
	nCurrVUserID=CInt(lr.eval_int("{VuserID}"))
	lr.output_message("nCurrentVUserID= " & nCurrVUserID)
    nTotalTestsInList = CLng(objRecordset.RecordCount)
    nTotalObjectsPerVuser = CLng(nTotalTestsInList /Clng(lr.eval_string("{Vusers#}")))   
    
    nMinItemInObjectsList = (nCurrVUserID * nTotalObjectsPerVuser)  +1
    nMaxItemInObjectsList = ((nCurrVUserID+1) * nTotalObjectsPerVuser ) - 1

    lr.output_message ">>> Total Tests In Filter: " + Cstr (nTotalTestsInList)
    lr.output_message ">>> nTotalObjectsPerVuser: " + Cstr (nTotalObjectsPerVuser)

    set objCommand = Nothing

    exit sub
    
If Err.Number <> 0 Then
	set objCommand = Nothing
    WScript.Echo "Error: " & Err.Number
    WScript.Echo "Error (Hex): " & Hex(Err.Number)
    WScript.Echo "Source: " &  Err.Source
    WScript.Echo "Error in subMinMaxTestIDRecSetPerVuser: " &  Err.Description
    lr.error_message "Error in subMinMaxTestIDRecSetPerVuser: " & Err.Description
    Err.Clear
	lr.abort
end If
end sub

' GetReqByPath
'=============
' This function returns a Req object specified by its
' full path. For example:
'
' set r = GetReqByPath("SCRATCH\OTA_REQ_DEMO\OTA_S_O_1")
' returns the OTA_S_O_1 object.
' A requirement name is not unique in the project, but it is
' unique a direct child of another requirement.
' Therefore, these routine works by walking down the
' requirement tree along the fullPath until the requirement
' is found at the end of the path.
'
' if a backslash is not used the folder delimiter, any other
' character can be passed in the delimChar argurment.
'public function GetReqByPath(tdc TDConnection, fullPath$, optional delimChar  = "\") req
public function GetReqByPath(tdc, fullPath, delimChar)
on error resume next
    dim rFact, theReq, ParentReq, reqList
    dim NodeArray(), PathArray()
    dim WorkingDepth
	dim delimCharLoc
	
	if delimChar is nothing Then 
		delimCharLoc = "\"
	else
		delimCharLoc = delimChar
	end if

    ' Trim the fullPath and strip leading and trailing delimiters.
    fullPath = Trim(fullPath)
    dim pos, ln
    pos = InStr(1, fullPath, delimCharLoc)
    if pos = 1 Then
        fullPath = Mid(fullPath, 2)
    end if
    
    ln = Len(fullPath)
    pos = InStr(ln - 1, fullPath, delimCharLoc)

    if pos > 0 Then
        fullPath = Mid(fullPath, 1, ln - 1)
    end if
    
    ' Get an array of requirements, and the length
    ' of the path.
    NodeArray = Split(fullPath, delimCharLoc)
    'WorkingDepth = UBound(NodeArray)

    ' Walk down the tree.
    'tdc is the global TDConnection object.
    set rFact = tdc.reqFactory
    For WorkingDepth = LBound(NodeArray) To UBound(NodeArray)
        ' First time, find under the root (-1).
        'After that, under the previous requirement found: ParentReq.ID
        if WorkingDepth = LBound(NodeArray) Then
            set reqList = rFact.Find(-1, "RQ_REQ_NAME", _
            NodeArray(WorkingDepth), TDREQMODE_FIND_EXACT)
        else
            set reqList = rFact.Find(ParentReq.ID, "RQ_REQ_NAME", _
            NodeArray(WorkingDepth), TDREQMODE_FIND_EXACT)
        end if

        ' Delete parent. Each loop has to find it again.
        set ParentReq = Nothing
        dim strItem, reqID, strID, thePath

        'Get a single string from the list returned
        'by ReqFactory.Find. We know it's the first
        'item because the filter can only return one
        'item that exactly matches the RQ_REQ_NAME.
        strItem = reqList(1)

        ' ReqFactory.Find returns a List
        ' of strings of format: ID,Name.
        ' For example "9,Products/Services On Sale"
        ' Extract the ID from the string by splitting the
        ' string at the comma.
        pos = InStr(strItem, ",")
        strID = Mid(strItem, 1, pos - 1)

        ' Convert the ID to a long, and get the object
        reqID = CLng(strID)
        set theReq = rFact.Item(reqID)

        'Now check that the object is at the correct depth.
        'if so, we've found the requirement. On the next loop,
        'we'll look from here down.
        thePath = theReq.Path
        PathArray = Split(thePath, "\")
        ' Debug.Print "Number of elements is " & UBound(PathArray)
        ' Debug.Print theReq.ID, theReq.Name
        set ParentReq = theReq
        if UBound(PathArray) = WorkingDepth Then exit for

        if ParentReq Is Nothing Then exit For
    Next 

    set GetReqByPath = ParentReq

    exit function

If Err.Number <> 0 Then
	set GetReqByPath = Nothing
    WScript.Echo "Error: " & Err.Number
    WScript.Echo "Error (Hex): " & Hex(Err.Number)
    WScript.Echo "Source: " &  Err.Source
    WScript.Echo "Error in GetReqByPath: " &  Err.Description
    lr.error_message "Error in GetReqByPath: " + Err.Description
    Err.Clear
	lr.abort
end If
end function

' fGetRequirementByQuery
'=======================
public function fGetRequirementByQuery (strSQL ) Recordset
on error resume next
    dim objCommand 'TDAPIOLELib.Command
    set objCommand = tdconnection.Command
    objCommand.CommandText = strSQL
    set objRecordset = objCommand.Execute
    set fGetRequirementByQuery = objRecordset

    set objCommand = Nothing
    set objRecordset = Nothing

    exit function

If Err.Number <> 0 Then
	set objCommand = Nothing
    set objRecordset = Nothing
    WScript.Echo "Error: " & Err.Number
    WScript.Echo "Error (Hex): " & Hex(Err.Number)
    WScript.Echo "Source: " &  Err.Source
    WScript.Echo "Error in fGetRequirementByQuery: " &  Err.Description
    lr.error_message "Error in fGetRequirementByQuery: " + Err.Description
    Err.Clear
	lr.abort
end If
end function

' GetRootChilds
'==============
' This function returns a List object containing all req ID from a given root and with a given name (optional)
' Parameters: 
'  tdc -> TD connection
'  RootID -> the ID of the req from wich we want to search (Requirement root tree is 0)
'  StrInReqName -> The string we want to match into requirement name
'public function GetRootChilds(tdc TDConnection, RootID , Optional StrInReqName ) 
public function GetRootChilds(tdc, RootID, StrInReqName) 
on error resume next
    dim reqFactory 'reqFactory
    dim mainReqList 
    dim currentReq 'req
    dim ReqColl  
    dim strCondition
    dim StrInReqNameLoc
    
    if StrInReqName is nothing Then
    	StrInReqNameLoc = ""
    else 
    	StrInReqNameLoc = StrInReqName
    end if
    
    set reqFactory = tdc.reqFactory
    set mainReqList = reqFactory.GetChildrenList(RootID)
    
    for Each currentReq In mainReqList
        if currentReq.Count > 0 then
            if StrInReqNameLoc <> "" then
                if Instr(currentReq.Name, StrInReqNameLoc) > 0 then
                    ReqColl.add currentReq.ID
                end if
            else
                ReqColl.add currentReq.ID    
            end if
        end if          
    Next

    set GetRootChilds = ReqColl
    
    exit function

If Err.Number <> 0 Then
    WScript.Echo "Error: " & Err.Number
    WScript.Echo "Error (Hex): " & Hex(Err.Number)
    WScript.Echo "Source: " &  Err.Source
    WScript.Echo "Error in GetRootChilds: " &  Err.Description
    lr.error_message "Error in GetRootChilds: " + Err.Description
    Err.Clear
	lr.abort
end If
end function

' getBugsWithAttachment
'======================
public function getBugsWithAttachment 
on error resume next
    dim bFact 'bugFactory
    dim filterText 

    set bFact = tdconnection.bugFactory
    filterText = "[Filter]{TableName:BUG, ColumnName:BG_ATTACHMENT, LogicalFilter:Y, NO_CASE:}"
    'dim list 
    set getBugsWithAttachment = bFact(filterText)
    
    exit function

If Err.Number <> 0 Then
    WScript.Echo "Error: " & Err.Number
    WScript.Echo "Error (Hex): " & Hex(Err.Number)
    WScript.Echo "Source: " &  Err.Source
    WScript.Echo "Error in getBugsWithAttachment: " &  Err.Description
	lr.error_message "Error in getBugsWithAttachment: " + Err.Description
    Err.Clear
	lr.abort
end If
end function

' getTestFolderFilteredChildrensList
'===================================
public function getTestFolderFilteredChildrensList(tdconnection, path , FolderPartialName ) 
on error resume next
    dim objTreeManager 'TreeManager
    dim objSubjectNode 'SubjectNode
    dim folderFilter 'TDFilter
    dim childFolderList 
    dim filteredList 
    dim currentFolder 'SubjectNode
    dim name 
    
    set objTreeManager = tdconnection.TreeManager
    set objSubjectNode = objTreeManager.NodeByPath(path)
    set childFolderList = objSubjectNode.NewList    
    
    For Each currentFolder In childFolderList
        name = currentFolder.name
        
        if InStr(name, FolderPartialName) <> 0 Then
            filteredList.Add (currentFolder.NodeID)
        end if    
    Next
    
    set getTestFolderFilteredChildrensList = filteredList
    
    exit function

If Err.Number <> 0 Then
    WScript.Echo "Error: " & Err.Number
    WScript.Echo "Error (Hex): " & Hex(Err.Number)
    WScript.Echo "Source: " &  Err.Source
    WScript.Echo "Error in getTestFolderFilteredChildrensList: " &  Err.Description
	lr.error_message "Error in getTestFolderFilteredChildrensList: " + Err.Description
    Err.Clear
	lr.abort
end If
end function

