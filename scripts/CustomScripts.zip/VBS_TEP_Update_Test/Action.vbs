'"'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
'" Script Title       :
'"
'" Script Date        :
'"'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
Public Function Action()
    dim objTestFactory
    dim objTest
    dim testVcs
    dim objDesignStepFactory
    dim objDesignStep
    dim objFilter
    dim objList
    dim strCurrentOpenTransactionName
    dim strTestType
    dim iItem
    dim strFilter
    dim iMinItemInTestsList
	dim iMaxItemInTestsList
	dim iTestsCount
	dim i
	
    set objTestFactory = tdconnection.TestFactory    
    subMinMaxTestIDRecSetPerVuser iMinItemInTestsList, iMaxItemInTestsList        

    do	
		Randomize
    	iItem = CLng((iMaxItemInTestsList - iMinItemInTestsList + 1) * Rnd()) + iMinItemInTestsList        
	   	objRecordset.Position = iItem 
    	iItem = objRecordset.FieldValue(0)
	   	strCurrentOpenTransactionName = "VB_TEP_UpdateTest_T01_FindTest"    
    	lr.think_time 10    
    	lr.start_transaction strCurrentOpenTransactionName
        	set objFilter = objTestFactory.Filter
        	objFilter.Filter("TS_TEST_ID")="=" +  Cstr(iItem) 
        	set objList = objFilter.NewList()
    	lr.end_transaction  strCurrentOpenTransactionName , lr.AUTO
	Loop while objList.Item(1).IsLocked = "TRUE" 

   		set objTest = objList.Item(1)
	    lr.message "Chosen TestID: " + Cstr(objTest.ID)
    	strTestType= Cstr(objTest.type)
	
    'When VC is enable - Check Out Test
    if isVCProject then  
        set testVcs = objTest.VCS    
        lr.think_time 10        
        strCurrentOpenTransactionName = "VB_TEP_UpdateTest_T08_CheckOutTest_" + strTestType
        lr.start_transaction strCurrentOpenTransactionName
            testVcs.CheckOut -1, "Check out comment", FALSE
        lr.end_transaction strCurrentOpenTransactionName, lr.AUTO
    end if

    strCurrentOpenTransactionName = "VB_TEP_UpdateTest_T03_GoToDesignStepsTab_" + strTestType
    lr.think_time 10
    lr.start_transaction strCurrentOpenTransactionName
        set objDesignStepFactory = objTest.DesignStepFactory
        set objList = objDesignStepFactory.NewList("")
    lr.end_transaction strCurrentOpenTransactionName, lr.AUTO

    lr.think_time 10
    strCurrentOpenTransactionName="VB_TEP_UpdateTest_T04_LockUpdateDesStep_" + strTestType
    lr.start_transaction strCurrentOpenTransactionName
        set objDesignStep = objList.Item(1)
        objDesignStep.LockObject
	objDesignStep.StepDescription = "<html><body>Adding Step Description Number : 1 Updated "+lr.eval_string("{currentDateTime}")+"</body></html>"
    lr.end_transaction strCurrentOpenTransactionName, lr.AUTO

	lr.think_time 10
    strCurrentOpenTransactionName="VB_TEP_UpdateTest_T05_PostUnlockDesStep_" + strTestType
    lr.start_transaction strCurrentOpenTransactionName
        objDesignStep.Post
        objDesignStep.UnLockObject    
    lr.end_transaction strCurrentOpenTransactionName, lr.AUTO

    lr.think_time 10    
    'When VC is enable - CheckIn Test
    if isVCProject then  
        strCurrentOpenTransactionName = "VB_TEP_UpdateTest_T09_CheckInTest_" + strTestType
        lr.start_transaction strCurrentOpenTransactionName
            testVcs.CheckIn "", "Check in comment"
        lr.end_transaction strCurrentOpenTransactionName, lr.AUTO
    end if     
    
    set objTestFactory = nothing
    set objTest  = nothing
    set testVcs = nothing
    set objDesignStepFactory   = nothing
    set objDesignStep   = nothing
    set objFilter  = nothing
    set objList  = nothing

    Action = lr.PASS
    
    exit function

    Action = lr.PASS
End Function
