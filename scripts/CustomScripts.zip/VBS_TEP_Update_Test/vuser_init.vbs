'"'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
'" Script Title       : VBS_TEPUpdateTest
'" Script Description : Update Test
'"                      
'"                      
'" Script Author      :
'" Script Date        :
'"'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
Public Function Init()
	InitQC()
    Init = lr.PASS
End Function
	
' InitQC
'=======
public sub InitQC() 
    dim pProps
    dim strCurrentOpenTransactionName
    
    Set tdconnection = objectHelper.CreateObject("TDApiOle80.TDConnection.1")
    SetAttributes
    SelectProject
    SelectUserName
    
    strCurrentOpenTransactionName ="VB_T01_Login"
    lr.start_transaction strCurrentOpenTransactionName 
        tdconnection.InitConnection GetAttribute("ServerName"), "", ""
    lr.end_transaction strCurrentOpenTransactionName, lr.AUTO

    strCurrentOpenTransactionName ="VB_T02_ConnectProject"  
    lr.start_transaction strCurrentOpenTransactionName 
        tdconnection.ConnectProjectEx GetAttribute("ServerDomain"), GetAttribute("Project"), GetAttribute("UserName"), DEFAULT_PASSWORD
    lr.end_transaction strCurrentOpenTransactionName, lr.AUTO

    Set pProps = tdconnection.ProjectProperties
    if pProps.ParamValue("VCS") = "Y" then
        isVCProject = True
        lr.save_string "prmVCS", "Y"
    else
        isVCProject = False    
    end if

    exit sub
    
end sub