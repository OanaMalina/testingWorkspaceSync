'"'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
'" Script Title       :
'"
'" Script Date        :
'"'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
Public Function Terminate()
    dim strCurrentOpenTransactionName
    
    if tdconnection.Connected = True then
        strCurrentOpenTransactionName = "Global_04_DisconnectProject"
        lr.start_transaction strCurrentOpenTransactionName 
            tdconnection.DisconnectProject
            tdconnection.ReleaseConnection
        lr.end_transaction strCurrentOpenTransactionName, lr.PASS    
    end if
    
    set tdconnection = Nothing
    exit function

    Terminate = lr.PASS
	
End Function
