vuser_end()
{

	Exit_QC ();

	return 0;
}
