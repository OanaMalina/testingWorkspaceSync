# 1 "c:\\users\\stepanvl.hpeswlab\\appdata\\local\\temp\\8\\td_80\\12.53.0.0_952\\9387d090\\test\\208\\208\\1003\\\\combined_1003.c"
# 1 "C:\\Program Files (x86)\\HP\\Performance Center Host\\include/lrun.h" 1
 
 












 











# 103 "C:\\Program Files (x86)\\HP\\Performance Center Host\\include/lrun.h"






















































		


		typedef unsigned size_t;
	
	
        
	

















	

 



















 
 
 
 
 


 
 
 
 
 
 














int     lr_start_transaction   (char * transaction_name);
int lr_start_sub_transaction          (char * transaction_name, char * trans_parent);
long lr_start_transaction_instance    (char * transaction_name, long parent_handle);
int   lr_start_cross_vuser_transaction		(char * transaction_name, char * trans_id_param); 



int     lr_end_transaction     (char * transaction_name, int status);
int lr_end_sub_transaction            (char * transaction_name, int status);
int lr_end_transaction_instance       (long transaction, int status);
int   lr_end_cross_vuser_transaction	(char * transaction_name, char * trans_id_param, int status);


 
typedef char* lr_uuid_t;
 



lr_uuid_t lr_generate_uuid();

 


int lr_generate_uuid_free(lr_uuid_t uuid);

 



int lr_generate_uuid_on_buf(lr_uuid_t buf);

   
# 273 "C:\\Program Files (x86)\\HP\\Performance Center Host\\include/lrun.h"
int lr_start_distributed_transaction  (char * transaction_name, lr_uuid_t correlator, long timeout  );

   







int lr_end_distributed_transaction  (lr_uuid_t correlator, int status);


double lr_stop_transaction            (char * transaction_name);
double lr_stop_transaction_instance   (long parent_handle);


void lr_resume_transaction           (char * trans_name);
void lr_resume_transaction_instance  (long trans_handle);


int lr_update_transaction            (const char *trans_name);


 
void lr_wasted_time(long time);


 
int lr_set_transaction(const char *name, double duration, int status);
 
long lr_set_transaction_instance(const char *name, double duration, int status, long parent_handle);


int   lr_user_data_point                      (char *, double);
long lr_user_data_point_instance                   (char *, double, long);
 



int lr_user_data_point_ex(const char *dp_name, double value, int log_flag);
long lr_user_data_point_instance_ex(const char *dp_name, double value, long parent_handle, int log_flag);


int lr_transaction_add_info      (const char *trans_name, char *info);
int lr_transaction_instance_add_info   (long trans_handle, char *info);
int lr_dpoint_add_info           (const char *dpoint_name, char *info);
int lr_dpoint_instance_add_info        (long dpoint_handle, char *info);


double lr_get_transaction_duration       (char * trans_name);
double lr_get_trans_instance_duration    (long trans_handle);
double lr_get_transaction_think_time     (char * trans_name);
double lr_get_trans_instance_think_time  (long trans_handle);
double lr_get_transaction_wasted_time    (char * trans_name);
double lr_get_trans_instance_wasted_time (long trans_handle);
int    lr_get_transaction_status		 (char * trans_name);
int	   lr_get_trans_instance_status		 (long trans_handle);

 



int lr_set_transaction_status(int status);

 



int lr_set_transaction_status_by_name(int status, const char *trans_name);
int lr_set_transaction_instance_status(int status, long trans_handle);


typedef void* merc_timer_handle_t;
 

merc_timer_handle_t lr_start_timer();
double lr_end_timer(merc_timer_handle_t timer_handle);


 
 
 
 
 
 











 



int   lr_rendezvous  (char * rendezvous_name);
 




int   lr_rendezvous_ex (char * rendezvous_name);



 
 
 
 
 
char *lr_get_vuser_ip (void);
void   lr_whoami (int *vuser_id, char ** sgroup, int *scid);
char *	  lr_get_host_name (void);
char *	  lr_get_master_host_name (void);

 
long     lr_get_attrib_long	(char * attr_name);
char *   lr_get_attrib_string	(char * attr_name);
double   lr_get_attrib_double      (char * attr_name);

char * lr_paramarr_idx(const char * paramArrayName, unsigned int index);
char * lr_paramarr_random(const char * paramArrayName);
int    lr_paramarr_len(const char * paramArrayName);

int	lr_param_unique(const char * paramName);
int lr_param_sprintf(const char * paramName, const char * format, ...);


 
 
static void *ci_this_context = 0;






 








void lr_continue_on_error (int lr_continue);
char *   lr_decrypt (const char *EncodedString);


 
 
 
 
 
 



 







 















void   lr_abort (void);
void lr_exit(int exit_option, int exit_status);
void lr_abort_ex (unsigned long flags);

void   lr_peek_events (void);


 
 
 
 
 


void   lr_think_time (double secs);

 


void lr_force_think_time (double secs);


 
 
 
 
 



















int   lr_msg (char * fmt, ...);
int   lr_debug_message (unsigned int msg_class,
									    char * format,
										...);
# 512 "C:\\Program Files (x86)\\HP\\Performance Center Host\\include/lrun.h"
void   lr_new_prefix (int type,
                                 char * filename,
                                 int line);
# 515 "C:\\Program Files (x86)\\HP\\Performance Center Host\\include/lrun.h"
int   lr_log_message (char * fmt, ...);
int   lr_message (char * fmt, ...);
int   lr_error_message (char * fmt, ...);
int   lr_output_message (char * fmt, ...);
int   lr_vuser_status_message (char * fmt, ...);
int   lr_error_message_without_fileline (char * fmt, ...);
int   lr_fail_trans_with_error (char * fmt, ...);

 
 
 
 
 
# 539 "C:\\Program Files (x86)\\HP\\Performance Center Host\\include/lrun.h"

 
 
 
 
 





int   lr_next_row ( char * table);
int lr_advance_param ( char * param);



														  
														  

														  
														  

													      
 


char *   lr_eval_string (char * str);
int   lr_eval_string_ext (const char *in_str,
                                     unsigned long const in_len,
                                     char ** const out_str,
                                     unsigned long * const out_len,
                                     unsigned long const options,
                                     const char *file,
								     long const line);
# 573 "C:\\Program Files (x86)\\HP\\Performance Center Host\\include/lrun.h"
void   lr_eval_string_ext_free (char * * pstr);

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
int lr_param_increment (char * dst_name,
                              char * src_name);
# 596 "C:\\Program Files (x86)\\HP\\Performance Center Host\\include/lrun.h"













											  
											  

											  
											  
											  

int	  lr_save_var (char *              param_val,
							  unsigned long const param_val_len,
							  unsigned long const options,
							  char *			  param_name);
# 620 "C:\\Program Files (x86)\\HP\\Performance Center Host\\include/lrun.h"
int   lr_save_string (const char * param_val, const char * param_name);



int   lr_set_custom_error_message (const char * param_val, ...);

int   lr_remove_custom_error_message ();


int   lr_free_parameter (const char * param_name);
int   lr_save_int (const int param_val, const char * param_name);
int   lr_save_timestamp (const char * tmstampParam, ...);
int   lr_save_param_regexp (const char *bufferToScan, unsigned int bufSize, ...);

int   lr_convert_double_to_integer (const char *source_param_name, const char * target_param_name);
int   lr_convert_double_to_double (const char *source_param_name, const char *format_string, const char * target_param_name);

 
 
 
 
 
 
# 699 "C:\\Program Files (x86)\\HP\\Performance Center Host\\include/lrun.h"
void   lr_save_datetime (const char *format, int offset, const char *name);









 











 
 
 
 
 






 



char * lr_error_context_get_entry (char * key);

 



long   lr_error_context_get_error_id (void);


 
 
 

int lr_table_get_rows_num (char * param_name);

int lr_table_get_cols_num (char * param_name);

char * lr_table_get_cell_by_col_index (char * param_name, int row, int col);

char * lr_table_get_cell_by_col_name (char * param_name, int row, const char* col_name);

int lr_table_get_column_name_by_index (char * param_name, int col, 
											char * * const col_name,
											size_t * col_name_len);
# 760 "C:\\Program Files (x86)\\HP\\Performance Center Host\\include/lrun.h"

int lr_table_get_column_name_by_index_free (char * col_name);

 
 
 
 
# 775 "C:\\Program Files (x86)\\HP\\Performance Center Host\\include/lrun.h"
int   lr_zip (const char* param1, const char* param2);
int   lr_unzip (const char* param1, const char* param2);

 
 
 
 
 
 
 
 

 
 
 
 
 
 
int   lr_param_substit (char * file,
                                   int const line,
                                   char * in_str,
                                   size_t const in_len,
                                   char * * const out_str,
                                   size_t * const out_len);
# 799 "C:\\Program Files (x86)\\HP\\Performance Center Host\\include/lrun.h"
void   lr_param_substit_free (char * * pstr);


 
# 811 "C:\\Program Files (x86)\\HP\\Performance Center Host\\include/lrun.h"





char *   lrfnc_eval_string (char * str,
                                      char * file_name,
                                      long const line_num);
# 819 "C:\\Program Files (x86)\\HP\\Performance Center Host\\include/lrun.h"


int   lrfnc_save_string ( const char * param_val,
                                     const char * param_name,
                                     const char * file_name,
                                     long const line_num);
# 825 "C:\\Program Files (x86)\\HP\\Performance Center Host\\include/lrun.h"

int   lrfnc_free_parameter (const char * param_name );







typedef struct _lr_timestamp_param
{
	int iDigits;
}lr_timestamp_param;

extern const lr_timestamp_param default_timestamp_param;

int   lrfnc_save_timestamp (const char * param_name, const lr_timestamp_param* time_param);

int lr_save_searched_string(char * buffer, long buf_size, unsigned int occurrence,
			    char * search_string, int offset, unsigned int param_val_len, 
			    char * param_name);

 
char *   lr_string (char * str);

 
# 926 "C:\\Program Files (x86)\\HP\\Performance Center Host\\include/lrun.h"

int   lr_save_value (char * param_val,
                                unsigned long const param_val_len,
                                unsigned long const options,
                                char * param_name,
                                char * file_name,
                                long const line_num);
# 933 "C:\\Program Files (x86)\\HP\\Performance Center Host\\include/lrun.h"


 
 
 
 
 











int   lr_printf (char * fmt, ...);
 
int   lr_set_debug_message (unsigned int msg_class,
                                       unsigned int swtch);
# 955 "C:\\Program Files (x86)\\HP\\Performance Center Host\\include/lrun.h"
unsigned int   lr_get_debug_message (void);


 
 
 
 
 

void   lr_double_think_time ( double secs);
void   lr_usleep (long);


 
 
 
 
 
 




int *   lr_localtime (long offset);


int   lr_send_port (long port);


# 1031 "C:\\Program Files (x86)\\HP\\Performance Center Host\\include/lrun.h"



struct _lr_declare_identifier{
	char signature[24];
	char value[128];
};

int   lr_pt_abort (void);

void vuser_declaration (void);






# 1060 "C:\\Program Files (x86)\\HP\\Performance Center Host\\include/lrun.h"


# 1072 "C:\\Program Files (x86)\\HP\\Performance Center Host\\include/lrun.h"
















 
 
 
 
 







int    _lr_declare_transaction   (char * transaction_name);


 
 
 
 
 







int   _lr_declare_rendezvous  (char * rendezvous_name);

 
 
 
 
 


typedef int PVCI;






typedef int VTCERR;









PVCI   vtc_connect(char * servername, int portnum, int options);
VTCERR   vtc_disconnect(PVCI pvci);
VTCERR   vtc_get_last_error(PVCI pvci);
VTCERR   vtc_query_column(PVCI pvci, char * columnName, int columnIndex, char * *outvalue);
VTCERR   vtc_query_row(PVCI pvci, int rowIndex, char * **outcolumns, char * **outvalues);
VTCERR   vtc_send_message(PVCI pvci, char * column, char * message, unsigned short *outRc);
VTCERR   vtc_send_if_unique(PVCI pvci, char * column, char * message, unsigned short *outRc);
VTCERR   vtc_send_row1(PVCI pvci, char * columnNames, char * messages, char * delimiter, unsigned char sendflag, unsigned short *outUpdates);
VTCERR   vtc_update_message(PVCI pvci, char * column, int index , char * message, unsigned short *outRc);
VTCERR   vtc_update_message_ifequals(PVCI pvci, char * columnName, int index,	char * message, char * ifmessage, unsigned short 	*outRc);
VTCERR   vtc_update_row1(PVCI pvci, char * columnNames, int index , char * messages, char * delimiter, unsigned short *outUpdates);
VTCERR   vtc_retrieve_message(PVCI pvci, char * column, char * *outvalue);
VTCERR   vtc_retrieve_messages1(PVCI pvci, char * columnNames, char * delimiter, char * **outvalues);
VTCERR   vtc_retrieve_row(PVCI pvci, char * **outcolumns, char * **outvalues);
VTCERR   vtc_rotate_message(PVCI pvci, char * column, char * *outvalue, unsigned char sendflag);
VTCERR   vtc_rotate_messages1(PVCI pvci, char * columnNames, char * delimiter, char * **outvalues, unsigned char sendflag);
VTCERR   vtc_rotate_row(PVCI pvci, char * **outcolumns, char * **outvalues, unsigned char sendflag);
VTCERR   vtc_increment(PVCI pvci, char * column, int index , int incrValue, int *outValue);
VTCERR   vtc_clear_message(PVCI pvci, char * column, int index , unsigned short *outRc);
VTCERR   vtc_clear_column(PVCI pvci, char * column, unsigned short *outRc);
VTCERR   vtc_ensure_index(PVCI pvci, char * column, unsigned short *outRc);
VTCERR   vtc_drop_index(PVCI pvci, char * column, unsigned short *outRc);
VTCERR   vtc_clear_row(PVCI pvci, int rowIndex, unsigned short *outRc);
VTCERR   vtc_create_column(PVCI pvci, char * column,unsigned short *outRc);
VTCERR   vtc_column_size(PVCI pvci, char * column, int *size);
void   vtc_free(char * msg);
void   vtc_free_list(char * *msglist);

VTCERR   lrvtc_connect(char * servername, int portnum, int options);
VTCERR   lrvtc_disconnect();
VTCERR   lrvtc_query_column(char * columnName, int columnIndex);
VTCERR   lrvtc_query_row(int columnIndex);
VTCERR   lrvtc_send_message(char * columnName, char * message);
VTCERR   lrvtc_send_if_unique(char * columnName, char * message);
VTCERR   lrvtc_send_row1(char * columnNames, char * messages, char * delimiter, unsigned char sendflag);
VTCERR   lrvtc_update_message(char * columnName, int index , char * message);
VTCERR   lrvtc_update_message_ifequals(char * columnName, int index, char * message, char * ifmessage);
VTCERR   lrvtc_update_row1(char * columnNames, int index , char * messages, char * delimiter);
VTCERR   lrvtc_retrieve_message(char * columnName);
VTCERR   lrvtc_retrieve_messages1(char * columnNames, char * delimiter);
VTCERR   lrvtc_retrieve_row();
VTCERR   lrvtc_rotate_message(char * columnName, unsigned char sendflag);
VTCERR   lrvtc_rotate_messages1(char * columnNames, char * delimiter, unsigned char sendflag);
VTCERR   lrvtc_rotate_row(unsigned char sendflag);
VTCERR   lrvtc_increment(char * columnName, int index , int incrValue);
VTCERR   lrvtc_noop();
VTCERR   lrvtc_clear_message(char * columnName, int index);
VTCERR   lrvtc_clear_column(char * columnName); 
VTCERR   lrvtc_ensure_index(char * columnName); 
VTCERR   lrvtc_drop_index(char * columnName); 
VTCERR   lrvtc_clear_row(int rowIndex);
VTCERR   lrvtc_create_column(char * columnName);
VTCERR   lrvtc_column_size(char * columnName);



 
 
 
 
 

 
int lr_enable_ip_spoofing();
int lr_disable_ip_spoofing();


 




int lr_convert_string_encoding(char * sourceString, char * fromEncoding, char * toEncoding, char * paramName);
int lr_read_file(const char *filename, const char *outputParam, int continueOnError);


 
int lr_db_connect (char * pFirstArg, ...);
int lr_db_disconnect (char * pFirstArg,	...);
int lr_db_executeSQLStatement (char * pFirstArg, ...);
int lr_db_dataset_action(char * pFirstArg, ...);
int lr_checkpoint(char * pFirstArg,	...);
int lr_db_getvalue(char * pFirstArg, ...);







 
 



















# 1 "c:\\users\\stepanvl.hpeswlab\\appdata\\local\\temp\\8\\td_80\\12.53.0.0_952\\9387d090\\test\\208\\208\\1003\\\\combined_1003.c" 2

# 1 "C:\\Program Files (x86)\\HP\\Performance Center Host\\include/SharedParameter.h" 1



 
 
 
 
# 100 "C:\\Program Files (x86)\\HP\\Performance Center Host\\include/SharedParameter.h"






typedef int PVCI2;






typedef int VTCERR2;


 
 
 

 
extern PVCI2    vtc_connect(char *servername, int portnum, int options);
extern VTCERR2  vtc_disconnect(PVCI2 pvci);
extern VTCERR2  vtc_get_last_error(PVCI2 pvci);

 
extern VTCERR2  vtc_query_column(PVCI2 pvci, char *columnName, int columnIndex, char **outvalue);
extern VTCERR2  vtc_query_row(PVCI2 pvci, int columnIndex, char ***outcolumns, char ***outvalues);
extern VTCERR2  vtc_send_message(PVCI2 pvci, char *column, char *message, unsigned short *outRc);
extern VTCERR2  vtc_send_if_unique(PVCI2 pvci, char *column, char *message, unsigned short *outRc);
extern VTCERR2  vtc_send_row1(PVCI2 pvci, char *columnNames, char *messages, char *delimiter,  unsigned char sendflag, unsigned short *outUpdates);
extern VTCERR2  vtc_update_message(PVCI2 pvci, char *column, int index , char *message, unsigned short *outRc);
extern VTCERR2  vtc_update_message_ifequals(PVCI2 pvci, char	*columnName, int index,	char *message, char	*ifmessage,	unsigned short 	*outRc);
extern VTCERR2  vtc_update_row1(PVCI2 pvci, char *columnNames, int index , char *messages, char *delimiter, unsigned short *outUpdates);
extern VTCERR2  vtc_retrieve_message(PVCI2 pvci, char *column, char **outvalue);
extern VTCERR2  vtc_retrieve_messages1(PVCI2 pvci, char *columnNames, char *delimiter, char ***outvalues);
extern VTCERR2  vtc_retrieve_row(PVCI2 pvci, char ***outcolumns, char ***outvalues);
extern VTCERR2  vtc_rotate_message(PVCI2 pvci, char *column, char **outvalue, unsigned char sendflag);
extern VTCERR2  vtc_rotate_messages1(PVCI2 pvci, char *columnNames, char *delimiter, char ***outvalues, unsigned char sendflag);
extern VTCERR2  vtc_rotate_row(PVCI2 pvci, char ***outcolumns, char ***outvalues, unsigned char sendflag);
extern VTCERR2	vtc_increment(PVCI2 pvci, char *column, int index , int incrValue, int *outValue);
extern VTCERR2  vtc_clear_message(PVCI2 pvci, char *column, int index , unsigned short *outRc);
extern VTCERR2  vtc_clear_column(PVCI2 pvci, char *column, unsigned short *outRc);

extern VTCERR2  vtc_clear_row(PVCI2 pvci, int rowIndex, unsigned short *outRc);

extern VTCERR2  vtc_create_column(PVCI2 pvci, char *column,unsigned short *outRc);
extern VTCERR2  vtc_column_size(PVCI2 pvci, char *column, int *size);
extern VTCERR2  vtc_ensure_index(PVCI2 pvci, char *column, unsigned short *outRc);
extern VTCERR2  vtc_drop_index(PVCI2 pvci, char *column, unsigned short *outRc);

extern VTCERR2  vtc_noop(PVCI2 pvci);

 
extern void vtc_free(char *msg);
extern void vtc_free_list(char **msglist);

 


 




 




















 




 
 
 

extern VTCERR2  lrvtc_connect(char *servername, int portnum, int options);
extern VTCERR2  lrvtc_disconnect();
extern VTCERR2  lrvtc_query_column(char *columnName, int columnIndex);
extern VTCERR2  lrvtc_query_row(int columnIndex);
extern VTCERR2  lrvtc_send_message(char *columnName, char *message);
extern VTCERR2  lrvtc_send_if_unique(char *columnName, char *message);
extern VTCERR2  lrvtc_send_row1(char *columnNames, char *messages, char *delimiter,  unsigned char sendflag);
extern VTCERR2  lrvtc_update_message(char *columnName, int index , char *message);
extern VTCERR2  lrvtc_update_message_ifequals(char *columnName, int index, char 	*message, char *ifmessage);
extern VTCERR2  lrvtc_update_row1(char *columnNames, int index , char *messages, char *delimiter);
extern VTCERR2  lrvtc_retrieve_message(char *columnName);
extern VTCERR2  lrvtc_retrieve_messages1(char *columnNames, char *delimiter);
extern VTCERR2  lrvtc_retrieve_row();
extern VTCERR2  lrvtc_rotate_message(char *columnName, unsigned char sendflag);
extern VTCERR2  lrvtc_rotate_messages1(char *columnNames, char *delimiter, unsigned char sendflag);
extern VTCERR2  lrvtc_rotate_row(unsigned char sendflag);
extern VTCERR2  lrvtc_increment(char *columnName, int index , int incrValue);
extern VTCERR2  lrvtc_clear_message(char *columnName, int index);
extern VTCERR2  lrvtc_clear_column(char *columnName);
extern VTCERR2  lrvtc_clear_row(int rowIndex);
extern VTCERR2  lrvtc_create_column(char *columnName);
extern VTCERR2  lrvtc_column_size(char *columnName);
extern VTCERR2  lrvtc_ensure_index(char *columnName);
extern VTCERR2  lrvtc_drop_index(char *columnName);

extern VTCERR2  lrvtc_noop();

 
 
 

                               


 
 
 





















# 2 "c:\\users\\stepanvl.hpeswlab\\appdata\\local\\temp\\8\\td_80\\12.53.0.0_952\\9387d090\\test\\208\\208\\1003\\\\combined_1003.c" 2

# 1 "globals.h" 1



long startTime, curTime;
int SleepTime, ReportTime;

 
 

# 1 "C:\\Program Files (x86)\\HP\\Performance Center Host\\include/web_api.h" 1







# 1 "C:\\Program Files (x86)\\HP\\Performance Center Host\\include/as_web.h" 1



























































 




 



 











 





















 
 
 

  int
	web_add_filter(
		const char *		mpszArg,
		...
	);									 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_add_auto_filter(
		const char *		mpszArg,
		...
	);									 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
	
  int
	web_add_auto_header(
		const char *		mpszHeader,
		const char *		mpszValue);

  int
	web_add_header(
		const char *		mpszHeader,
		const char *		mpszValue);
  int
	web_add_cookie(
		const char *		mpszCookie);
  int
	web_cleanup_auto_headers(void);
  int
	web_cleanup_cookies(void);
  int
	web_concurrent_end(
		const char * const	mpszReserved,
										 
		...								 
	);
  int
	web_concurrent_start(
		const char * const	mpszConcurrentGroupName,
										 
										 
		...								 
										 
	);
  int
	web_create_html_param(
		const char *		mpszParamName,
		const char *		mpszLeftDelim,
		const char *		mpszRightDelim);
  int
	web_create_html_param_ex(
		const char *		mpszParamName,
		const char *		mpszLeftDelim,
		const char *		mpszRightDelim,
		const char *		mpszNum);
  int
	web_custom_request(
		const char *		mpszReqestName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	spdy_custom_request(
		const char *		mpszReqestName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_disable_keep_alive(void);
  int
	web_enable_keep_alive(void);
  int
	web_find(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_get_int_property(
		const int			miHttpInfoType);
  int
	web_image(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_image_check(
		const char *		mpszName,
		...);
  int
	web_java_check(
		const char *		mpszName,
		...);
  int
	web_link(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

	
  int
	web_global_verification(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 
										 
  int
	web_reg_find(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 
										 
										 
										 
				
  int
	web_reg_save_param(
		const char *		mpszParamName,
		...);							 
										 
										 
										 
										 
										 
										 

  int
	web_convert_param(
		const char * 		mpszParamName, 
										 
		...);							 
										 
										 


										 

										 
  int
	web_remove_auto_filter(
		const char *		mpszArg,
		...
	);									 
										 
				
  int
	web_remove_auto_header(
		const char *		mpszHeaderName,
		...);							 
										 



  int
	web_remove_cookie(
		const char *		mpszCookie);

  int
	web_save_header(
		const char *		mpszType,	 
		const char *		mpszName);	 
  int
	web_set_certificate(
		const char *		mpszIndex);
  int
	web_set_certificate_ex(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_set_connections_limit(
		const char *		mpszLimit);
  int
	web_set_max_html_param_len(
		const char *		mpszLen);
  int
	web_set_max_retries(
		const char *		mpszMaxRetries);
  int
	web_set_proxy(
		const char *		mpszProxyHost);
  int
	web_set_pac(
		const char *		mpszPacUrl);
  int
	web_set_proxy_bypass(
		const char *		mpszBypass);
  int
	web_set_secure_proxy(
		const char *		mpszProxyHost);
  int
	web_set_sockets_option(
		const char *		mpszOptionID,
		const char *		mpszOptionValue
	);
  int
	web_set_option(
		const char *		mpszOptionID,
		const char *		mpszOptionValue,
		...								 
	);
  int
	web_set_timeout(
		const char *		mpszWhat,
		const char *		mpszTimeout);
  int
	web_set_user(
		const char *		mpszUserName,
		const char *		mpszPwd,
		const char *		mpszHost);

  int
	web_sjis_to_euc_param(
		const char *		mpszParamName,
										 
		const char *		mpszParamValSjis);
										 

  int
	web_submit_data(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	spdy_submit_data(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_submit_form(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_url(
		const char *		mpszUrlName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	spdy_url(
		const char *		mpszUrlName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int 
	web_set_proxy_bypass_local(
		const char * mpszNoLocal
		);

  int 
	web_cache_cleanup(void);

  int
	web_create_html_query(
		const char* mpszStartQuery,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int 
	web_create_radio_button_param(
		const char *NameFiled,
		const char *NameAndVal,
		const char *ParamName
		);

  int
	web_convert_from_formatted(
		const char * mpszArg1,
		...);							 
										 
										 
										 
										 
										 
										
  int
	web_convert_to_formatted(
		const char * mpszArg1,
		...);							 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_ex(
		const char * mpszParamName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_xpath(
		const char * mpszParamName,
		...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_json(
		const char * mpszParamName,
		...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_regexp(
		 const char * mpszParamName,
		 ...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_js_run(
		const char * mpszCode,
		...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_js_reset(void);

  int
	web_convert_date_param(
		const char * 		mpszParamName,
		...);










# 769 "C:\\Program Files (x86)\\HP\\Performance Center Host\\include/as_web.h"


# 782 "C:\\Program Files (x86)\\HP\\Performance Center Host\\include/as_web.h"



























# 820 "C:\\Program Files (x86)\\HP\\Performance Center Host\\include/as_web.h"

 
 
 


  int
	FormSubmit(
		const char *		mpszFormName,
		...);
  int
	InitWebVuser(void);
  int
	SetUser(
		const char *		mpszUserName,
		const char *		mpszPwd,
		const char *		mpszHost);
  int
	TerminateWebVuser(void);
  int
	URL(
		const char *		mpszUrlName);
























# 888 "C:\\Program Files (x86)\\HP\\Performance Center Host\\include/as_web.h"


  int
	web_rest(
		const char *		mpszReqestName,
		...);							 
										 
										 
										 
										 

  int
web_stream_open(
	const char *		mpszArg1,
	...
);
  int
	web_stream_wait(
		const char *		mpszArg1,
		...
	);

  int
	web_stream_close(
		const char *		mpszArg1,
		...
	);

  int
web_stream_play(
	const char *		mpszArg1,
	...
	);

  int
web_stream_pause(
	const char *		mpszArg1,
	...
	);

  int
web_stream_seek(
	const char *		mpszArg1,
	...
	);

  int
web_stream_get_param_int(
	const char*			mpszStreamID,
	const int			miStateType
	);

  double
web_stream_get_param_double(
	const char*			mpszStreamID,
	const int			miStateType
	);

  int
web_stream_get_param_string(
	const char*			mpszStreamID,
	const int			miStateType,
	const char*			mpszParameterName
	);

  int
web_stream_set_param_int(
	const char*			mpszStreamID,
	const int			miStateType,
	const int			miStateValue
	);

  int
web_stream_set_param_double(
	const char*			mpszStreamID,
	const int			miStateType,
	const double		mdfStateValue
	);

 
 
 






# 9 "C:\\Program Files (x86)\\HP\\Performance Center Host\\include/web_api.h" 2

















 







 














  int
	web_reg_add_cookie(
		const char *		mpszCookie,
		...);							 
										 

  int
	web_report_data_point(
		const char *		mpszEventType,
		const char *		mpszEventName,
		const char *		mpszDataPointName,
		const char *		mpszLAST);	 
										 
										 
										 

  int
	web_text_link(
		const char *		mpszStepName,
		...);

  int
	web_element(
		const char *		mpszStepName,
		...);

  int
	web_image_link(
		const char *		mpszStepName,
		...);

  int
	web_static_image(
		const char *		mpszStepName,
		...);

  int
	web_image_submit(
		const char *		mpszStepName,
		...);

  int
	web_button(
		const char *		mpszStepName,
		...);

  int
	web_edit_field(
		const char *		mpszStepName,
		...);

  int
	web_radio_group(
		const char *		mpszStepName,
		...);

  int
	web_check_box(
		const char *		mpszStepName,
		...);

  int
	web_list(
		const char *		mpszStepName,
		...);

  int
	web_text_area(
		const char *		mpszStepName,
		...);

  int
	web_map_area(
		const char *		mpszStepName,
		...);

  int
	web_eval_java_script(
		const char *		mpszStepName,
		...);

  int
	web_reg_dialog(
		const char *		mpszArg1,
		...);

  int
	web_reg_cross_step_download(
		const char *		mpszArg1,
		...);

  int
	web_browser(
		const char *		mpszStepName,
		...);

  int
	web_control(
		const char *		mpszStepName,
		...);

  int
	web_set_rts_key(
		const char *		mpszArg1,
		...);

  int
	web_save_param_length(
		const char * 		mpszParamName,
		...);

  int
	web_save_timestamp_param(
		const char * 		mpszParamName,
		...);

  int
	web_load_cache(
		const char *		mpszStepName,
		...);							 
										 

  int
	web_dump_cache(
		const char *		mpszStepName,
		...);							 
										 
										 

  int
	web_reg_find_in_log(
		const char *		mpszArg1,
		...);							 
										 
										 

  int
	web_get_sockets_info(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 

  int
	web_add_cookie_ex(
		const char *		mpszArg1,
		...);							 
										 
										 
										 

  int
	web_hook_java_script(
		const char *		mpszArg1,
		...);							 
										 
										 
										 

 
 
 
 
 
 
 
 
 
 
 
 
  int
	web_reg_async_attributes(
		const char *		mpszArg,
		...
	);

 
 
 
 
 
 
  int
	web_sync(
		 const char *		mpszArg1,
		 ...
	);

 
 
 
 
  int
	web_stop_async(
		const char *		mpszArg1,
		...
	);

 
 
 
 
 

 
 
 

typedef enum WEB_ASYNC_CB_RC_ENUM_T
{
	WEB_ASYNC_CB_RC_OK,				 

	WEB_ASYNC_CB_RC_ABORT_ASYNC_NOT_ERROR,
	WEB_ASYNC_CB_RC_ABORT_ASYNC_ERROR,
										 
										 
										 
										 
	WEB_ASYNC_CB_RC_ENUM_COUNT
} WEB_ASYNC_CB_RC_ENUM;

 
 
 

typedef enum WEB_CONVERS_CB_CALL_REASON_ENUM_T
{
	WEB_CONVERS_CB_CALL_REASON_BUFFER_RECEIVED,
	WEB_CONVERS_CB_CALL_REASON_END_OF_TASK,

	WEB_CONVERS_CB_CALL_REASON_ENUM_COUNT
} WEB_CONVERS_CB_CALL_REASON_ENUM;

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

typedef
int														 
	(*RequestCB_t)();

typedef
int														 
	(*ResponseBodyBufferCB_t)(
		  const char *		aLastBufferStr,
		  int				aLastBufferLen,
		  const char *		aAccumulatedStr,
		  int				aAccumulatedLen,
		  int				aHttpStatusCode);

typedef
int														 
	(*ResponseCB_t)(
		  const char *		aResponseHeadersStr,
		  int				aResponseHeadersLen,
		  const char *		aResponseBodyStr,
		  int				aResponseBodyLen,
		  int				aHttpStatusCode);

typedef
int														 
	(*ResponseHeadersCB_t)(
		  int				aHttpStatusCode,
		  const char *		aAccumulatedHeadersStr,
		  int				aAccumulatedHeadersLen);



 
 
 

typedef enum WEB_CONVERS_UTIL_RC_ENUM_T
{
	WEB_CONVERS_UTIL_RC_OK,
	WEB_CONVERS_UTIL_RC_CONVERS_NOT_FOUND,
	WEB_CONVERS_UTIL_RC_TASK_NOT_FOUND,
	WEB_CONVERS_UTIL_RC_INFO_NOT_FOUND,
	WEB_CONVERS_UTIL_RC_INFO_UNAVIALABLE,
	WEB_CONVERS_UTIL_RC_INVALID_ARGUMENT,

	WEB_CONVERS_UTIL_RC_ENUM_COUNT
} WEB_CONVERS_UTIL_RC_ENUM;

 
 
 

  int					 
	web_util_set_request_url(
		  const char *		aUrlStr);

  int					 
	web_util_set_request_body(
		  const char *		aRequestBodyStr);

  int					 
	web_util_set_formatted_request_body(
		  const char *		aRequestBodyStr);


 
 
 
 
 

 
 
 
 
 

 
 
 
 
 
 
 
 

 
 
  int
web_websocket_connect(
		 const char *	mpszArg1,
		 ...
		 );


 
 
 
 
 																						
  int
web_websocket_send(
	   const char *		mpszArg1,
		...
	   );

 
 
 
 
 
 
  int
web_websocket_close(
		const char *	mpszArg1,
		...
		);

 
typedef
void														
(*OnOpen_t)(
			  const char* connectionID,  
			  const char * responseHeader,  
			  int length  
);

typedef
void														
(*OnMessage_t)(
	  const char* connectionID,  
	  int isbinary,  
	  const char * data,  
	  int length  
	);

typedef
void														
(*OnError_t)(
	  const char* connectionID,  
	  const char * message,  
	  int length  
	);

typedef
void														
(*OnClose_t)(
	  const char* connectionID,  
	  int isClosedByClient,  
	  int code,  
	  const char* reason,  
	  int length  
	 );
 
 
 
 
 





# 10 "globals.h" 2

# 1 "C:\\Program Files (x86)\\HP\\Performance Center Host\\include/lrw_custom_body.h" 1
 





# 11 "globals.h" 2


 
 

# 1 "\\\\mydstore0001\\HPSWLABS\\ALM\\PCoE\\QC\\Apollo\\Include\\FrecParcer.h" 1
int frecRecalculate (char *sTargetFrecParamName, char *sSourceFrec)
{
	char *sFrec ;
	char *sSourceParam ;

 
 
	sFrec = (char *) malloc (sizeof(char) * (strlen(lr_eval_string(sSourceFrec)) + 1 ) ) ;
	if (!sFrec)
	{
		lr_error_message ("Failed to alocate buffer size %d", sizeof(char) * (strlen(lr_eval_string(sSourceFrec)) + 1 )) ;
		
		return (0) ;
	}
	sprintf (sFrec, "%s", lr_eval_string(sSourceFrec)) ;

 

	frecMakeRecalculate (sFrec) ;

 

	lr_save_string (sFrec, sTargetFrecParamName) ;

	free (sFrec) ;
	
	return (1) ;
}

void qc_custom_request ( char *sName,
						 char *sURL,
						 char *sMethod,
						 char *sResource,
						 char *sRecContentType,
						 char *sReferer,
						 char *sSnapshot,
						 char *sMode,
						 char *sEncType,
						 char *sBodyBinary,
						 char *sLast
					)
{
	if (frecRecalculate ( "qcRecalculatedFrec", lr_eval_string(sBodyBinary) ))
	{
		web_custom_request (sName,
			sURL,
			sMethod,
			sResource,
			sRecContentType,
			sReferer,
			sSnapshot,
			sMode,
			sEncType,
			lr_eval_string("{qcRecalculatedFrec}"),
			"LAST") ;
	}
}

 
 
 
 
 
 
 
 
 
 
 
 
 
 


# 16 "globals.h" 2

# 1 "\\\\mydstore0001\\HPSWLABS\\ALM\\PCoE\\QC\\Apollo\\Include\\Initialize_QC_ALM1250_fix_temp.h" 1









 












# 1 "\\\\mydstore0001\\HPSWLABS\\ALM\\PCoE\\QC\\Apollo\\Include\\Utils.h" 1



void GenerateUniqueString (char *sOutputParamName, char *sBasicString, char *sConnectionCharacter)
{
	int 	nVUser_ID ;
	char	sVUser_ID [64] ;
	char	*sGroupName ;
	char	sOutputBuffer [1024];
    
	lr_whoami( &nVUser_ID, &sGroupName, 0 ) ;
	sprintf ( sVUser_ID, "%d", abs(nVUser_ID)) ;

    	lr_save_datetime("%m_%d_%Y_%H_%M_%S", 0, "GenerateUniqueString_TimeNow") ;

	 

	sprintf (sOutputBuffer, 
			"%s%s%s%s%s%s%s", 
			 sBasicString, 
			 sConnectionCharacter, 
			 sVUser_ID,
			 sConnectionCharacter, 
			 sGroupName,
			 sConnectionCharacter, 
			 lr_eval_string("{GenerateUniqueString_TimeNow}")
			 ) ;

	lr_save_string ( sOutputBuffer, sOutputParamName ) ;

	 
}

void GetDate (int nOffset)
{
	lr_save_datetime("%Y", 0 + nOffset, "CurrentYear") ;
	lr_save_datetime("%#m", 0 + nOffset, "CurrentMonth") ;
	lr_save_datetime("%#d", 0 + nOffset, "CurrentDay") ;
	lr_save_datetime("%#H", 0 + nOffset, "CurrentHour") ;
	lr_save_datetime("%#M", 0 + nOffset, "CurrentMinute") ;
	lr_save_datetime("%#S", 0 + nOffset, "CurrentSecond") ;
}


 
# 62 "\\\\mydstore0001\\HPSWLABS\\ALM\\PCoE\\QC\\Apollo\\Include\\Utils.h"
int ParamCat (char *sParamName, char *sOutParamName, char *sDelimiter, int nStartAt, int nCount, char* sPrefix, char* sSuffix)
{
	char 	*sFullParamName ;
	char 	*sParamName_count ;
	char	*sOutputBuffer ;
	char	*sOutputBuffer_Temp ;
	
	int	nListSize ;
	int	nCurrentIndex ;
	int	nListParamsLength ;

	int	nOutputBufferLength ;
	int	nDelimiterLength ;
	int	nPrefixLength ;
	int	nSuffixLength ;

	 


	sParamName_count = (char *) malloc (sizeof (char) * ( strlen(sParamName) + strlen("{_count}") + 1) ) ;
	if (sParamName_count == 0)
		return (0) ;
		
	sprintf (sParamName_count, "{%s_count}", sParamName) ;

	 


	sFullParamName = (char *) malloc (sizeof (char) * ( strlen(sParamName) + strlen("{}_") + strlen(lr_eval_string(sParamName_count)) + 1) ) ;
	if (sFullParamName == 0)
		return (0) ;

	 


	nListSize = atoi(lr_eval_string(sParamName_count)) ;

	if (nStartAt > nListSize )
		return (0) ;

	 


	if (!nCount)
		nCount = nListSize ;

	 


	nOutputBufferLength = 0 ;
	nDelimiterLength = strlen (sDelimiter) ;
	nPrefixLength = strlen (sPrefix) ;
	nSuffixLength = strlen (sSuffix) ;
	
	for ( nCurrentIndex = 0 ; nCurrentIndex < nCount && nStartAt + nCurrentIndex <= nListSize ; nCurrentIndex++ ) 
	{
		sprintf ( sFullParamName, "{%s_%d}", sParamName, nStartAt + nCurrentIndex ) ;	
		nOutputBufferLength +=  nPrefixLength + strlen(lr_eval_string(sFullParamName)) + nSuffixLength + nDelimiterLength ;
	}

	nOutputBufferLength -= nDelimiterLength ;
	sOutputBuffer = (char *) calloc ( nOutputBufferLength + 1 + 2, sizeof (char) ) ;  
	if (sOutputBuffer == 0)
		return (0) ;

	 


	for (sOutputBuffer[0] = '\0', nCurrentIndex = 0 ; nCurrentIndex < nCount && nStartAt + nCurrentIndex <= nListSize ; nCurrentIndex++ ) 
	{
		sprintf ( sFullParamName, "{%s_%d}", sParamName, nStartAt + nCurrentIndex ) ;	

		if (nCurrentIndex)
			strcat (sOutputBuffer, sDelimiter) ;

		strcat (sOutputBuffer, sPrefix) ;
		strcat (sOutputBuffer, lr_eval_string(sFullParamName)) ;
		strcat (sOutputBuffer, sSuffix) ;
	}
	
	nListParamsLength = strlen(sOutputBuffer);

	if ( (nListParamsLength <= 16) && (strstr(sOutputBuffer, ",") != 0) )
	{
		 
		 
		sOutputBuffer_Temp = (char *)_strdup(sOutputBuffer);
		sprintf (sOutputBuffer, "\"%s\"", sOutputBuffer_Temp);
		 
		free(sOutputBuffer_Temp);
	}
	 


	lr_save_string(sOutputBuffer, sOutParamName) ;

	 


	free ( sOutputBuffer ) ;
	free ( sFullParamName ) ;
	free ( sParamName_count ) ;
	
	return ( nListParamsLength ) ; 
}

 



int ParamCatAndRecalculate (char *sParamName, char *sOutParamName, char *sDelimiter, int nStartAt, int nCount, char* sPrefix, char* sSuffix)
{
	int nLength ;

	char	*sBracketOutParamName ;
	char 	*sOutBuffer ;

	nLength = ParamCat (sParamName, sOutParamName, sDelimiter, nStartAt, nCount, sPrefix, sSuffix) ;
	if (!nLength)
		return (0) ;

	if (nLength <= 16) 
		return ( nLength ) ;	
	
	sBracketOutParamName = (char *) malloc ( sizeof (char) * strlen (sOutParamName) + strlen ("{}") + 1 ) ;
	if ( !sBracketOutParamName )
		return (0) ;
			
	sprintf (sBracketOutParamName, "{%s}", sOutParamName) ;



	sOutBuffer = (char *) malloc ( sizeof (char) * (strlen (lr_eval_string(sBracketOutParamName)) + strlen ("\\00000000\\") + 1 ) ) ;
	if ( !sOutBuffer )
		return (0) ;

	sprintf(sOutBuffer, "\\%.8X\\%s", strlen (lr_eval_string(sBracketOutParamName)) , lr_eval_string(sBracketOutParamName) ) ;

	lr_save_string (sOutBuffer, sOutParamName ) ;

	free ( sBracketOutParamName ) ;
	free ( sOutBuffer ) ;
	
	return ( nLength ) ;
}

 





void GetRandomParam (char *sParamName, char* sOutputParamName)
{
	char sTempParamName [64] ;

	int nIndex ;

	sprintf (sTempParamName, "{%s_count}", sParamName) ;

	srand(_time32(0)); 
	nIndex = rand() % atoi ( lr_eval_string (sTempParamName) ) ;

	sprintf (sTempParamName, "{%s_%d}", sParamName, nIndex  + 1) ;

	lr_save_string ( lr_eval_string (sTempParamName), sOutputParamName) ;
}

char *Eval_string_idx (char *sParamName, int nIndex)
{
	char	sFullParamName [1024] ;
	
	sprintf (sFullParamName, "{%s_%d}", sParamName, nIndex) ;
	return ( lr_eval_string (sFullParamName) ) ;	
}


 





int string_reg_save_param(char * ParameterName, char * LeftBoundary)
{
		char * startID;

		char buffer [1024] = {0};

		sprintf(buffer, "{%s}", ParameterName);

		 
		startID = (char *)strstr(lr_eval_string(buffer), LeftBoundary);
		if(startID)
		{
			startID = startID + strlen(LeftBoundary); 
			
			lr_save_string(startID, ParameterName);
		}
		else
			return 0;

		return 1;
}

char *pcoe_get_attrib_string (char *sAttributeName, char *sDefaultValue, char *sOutputParam, char *sEmptyValue)
{
	char *sAttrValue ;

	sAttrValue = lr_get_attrib_string( sAttributeName ) ;

	 


	if (sAttrValue)
	{
		 



		if (stricmp (sAttrValue, sEmptyValue) != 0)
		{
			if (sOutputParam) 
				lr_save_string (sAttrValue, sOutputParam) ;

			return (sAttrValue) ;
		}
	}

	 



	if (sOutputParam && sDefaultValue)
	{
		if (strlen (sOutputParam))
			lr_save_string (sDefaultValue, sOutputParam) ;
	}

	return (sDefaultValue) ;
}

long pcoe_get_attrib_long (char *sAttributeName, long nDefaultValue, char *sOutputParam, long nEmptyValue)
{
 	long nAttrValue ;
	long nReturnValue ;

	char sBuffer [64] ;

	nReturnValue = nDefaultValue ;

	nAttrValue = lr_get_attrib_long ( sAttributeName ) ;

	 


	if ( nAttrValue > -1 )
	{
		if ( nAttrValue != nEmptyValue )
			nReturnValue = nAttrValue ;
	}

	 





	if (sOutputParam)
	{
		if (strlen (sOutputParam))
		{
			sprintf (sBuffer, "%d", nReturnValue) ;
			lr_save_string ( sBuffer, sOutputParam ) ;
		}
	}

	return (nReturnValue) ;
}

int pcoe_save_random_string (int nMin, int nMax, char *sPrefix, char *sSuffix, char *sOutputParam)
{
	int		nRandomNumber ;
	char 	*sBuffer ;

	 



	srand( _time32(0) ) ;
	nRandomNumber = nMin + rand () % (nMax - nMin) ;

	return ( pcoe_save_param (sPrefix, nRandomNumber, sSuffix, sOutputParam) ) ;

}

int pcoe_save_param (char *sPrefix, int nNumber, char *sSuffix, char *sOutputParam)
{
	int		nRet ;
	char 	*sBuffer ;

	sBuffer = (char *) malloc ((sizeof (char) ) * ( strlen(sPrefix) + strlen(sSuffix) + 64)) ;
	sprintf ( sBuffer, "%s%d%s", sPrefix, nNumber, sSuffix) ;

	 


	nRet = lr_save_string (sBuffer, sOutputParam ) ;

	free (sBuffer) ;

	return (nRet) ;
}

void LocalRecalculate(char *sParamName, char* sOutParamName){
	char num[9];
	char fullParam[100];
	sprintf(fullParam,"{%s}",sParamName);
	sprintf(num,"%08x",strlen(lr_eval_string(fullParam)));
	lr_save_string(num,sOutParamName);
}



 
# 398 "\\\\mydstore0001\\HPSWLABS\\ALM\\PCoE\\QC\\Apollo\\Include\\Utils.h"
int Spe_Reg_Save_Param (char *SourceCorr, char *LB, char *RB, char *CorrName)
{

	int StartPosition;
	int EndPosition;

	StartPosition = (int)((char *)strstr(SourceCorr,LB ) - SourceCorr)+ strlen(LB);
	if(StartPosition < 0 )
		return 0;

	EndPosition = (int)((char *)strstr(SourceCorr,RB )- SourceCorr) - StartPosition;

	if(EndPosition < 0 )
		return 0;

	lr_save_var(SourceCorr + StartPosition, EndPosition, 0, CorrName);

	return 1;

}




 
# 438 "\\\\mydstore0001\\HPSWLABS\\ALM\\PCoE\\QC\\Apollo\\Include\\Utils.h"

 
void DynamicTRname(char *sTRFname, char *sTRchange, char *sTRLname, char *sParamName, char* sOutParamName){
	char trname[150];
	if(strcmp(sParamName,"Y")==0) 
		sprintf(trname,"%s_%s_%s",sTRFname,sTRLname,sTRchange);
	else
		sprintf(trname,"%s_%s",sTRFname,sTRLname);
		
	lr_save_string(trname,sOutParamName);
}

 
# 486 "\\\\mydstore0001\\HPSWLABS\\ALM\\PCoE\\QC\\Apollo\\Include\\Utils.h"


 
# 515 "\\\\mydstore0001\\HPSWLABS\\ALM\\PCoE\\QC\\Apollo\\Include\\Utils.h"
 
 

# 23 "\\\\mydstore0001\\HPSWLABS\\ALM\\PCoE\\QC\\Apollo\\Include\\Initialize_QC_ALM1250_fix_temp.h" 2


int	*pintPingThread;
int	bPingEnable = 1;
int 	nVUser_ID ;

void Init_Parameters ()
{
	long nUserFirst, nUserTotal ;
	
	web_remove_auto_header ("Content-Type", "LAST");  
	web_add_auto_header("Content-Type", "text/html"); 
	 


	if(strstr(pcoe_get_attrib_string ("LB", "False", "LB", ""),"True"))
	  {
		lr_whoami( &nVUser_ID, 0, 0 ) ;
		nVUser_ID = abs (nVUser_ID) ;
		if((nVUser_ID) % 2 == 0)
			{
				lr_save_string(lr_get_attrib_string("ServerName"),"ServerName");
			}
		else
			{
				lr_save_string(lr_get_attrib_string("ServerName2"),"ServerName");
			}
	  }
	else
		pcoe_get_attrib_string ("ServerName", "<Need server Name>:8080", "ServerName", "") ;


	 


	pcoe_get_attrib_string ("Domain", "DEFAULT", "Domain", "") ;

	 


	pcoe_get_attrib_string ("GraphProjects", "1", "GraphProjects", "") ;

	 


	nUserFirst = pcoe_get_attrib_long ("UserFirst", 1, "", -1) ;
	nUserTotal = pcoe_get_attrib_long ("UserTotal", 1000, "", -1) ;

	if (!pcoe_get_attrib_string ("UserName", 0, "UserName", "") || (stricmp(lr_eval_string("{UserName}"), "All" ) == 0 )) 	
	{
		pcoe_save_random_string (nUserFirst, nUserFirst + nUserTotal - 1, "admin", "", "UserName") ;
	}
		
	 


	pcoe_get_attrib_string ("Password", "", "Password", "") ;

	 


	lr_save_string(lr_get_attrib_string("BuildNumber"),"BuildNumber");

}

void Select_Project (char* sOutParameter, char* sProjectName_Prefix, char* sProjectName_Suffix)
{
	int 	nVUser_ID ;
	int 	nProjectIndex ;
	int 	nFirstProject ;
	int		nMainProjects ;
	int 	nTotalProjects ;

	 


	if (pcoe_get_attrib_string ("Project", 0, sOutParameter, "All"))
	{
		return ;
	}

	 



	 





	pcoe_get_attrib_string ("ProjectMethod", "", "ProjectMethod", "") ;
	if (stricmp ( lr_eval_string("{ProjectMethod}"), "New")) 
		nMainProjects = 1 ;
	else
		nMainProjects = 0 ;
    
	nFirstProject = pcoe_get_attrib_long ("ProjectFirst", 1, "", -1) ;
	nMainProjects = pcoe_get_attrib_long ("ProjectMain", nMainProjects, "", -1) ;
	nTotalProjects = pcoe_get_attrib_long ("ProjectTotal", 1, "", -1) ;

	 



	if (nMainProjects == nTotalProjects) 
		nMainProjects = 0 ;

	lr_whoami (&nVUser_ID, 0, 0) ;

	 



	if (nVUser_ID < 1) 
		nVUser_ID = 1 ;

	nProjectIndex = nVUser_ID % (nMainProjects + 1) ;
	if (nProjectIndex == 0)
	{
		srand(_time32(0));
		nProjectIndex = nFirstProject + nMainProjects + rand() % (nTotalProjects - nMainProjects);				
	}
	else
		nProjectIndex = nProjectIndex + nFirstProject - 1;

 	 



	pcoe_save_param (sProjectName_Prefix, nProjectIndex, "", sOutParameter) ;
}

void AddParamToList (char *Param_List, char *Param_To_Add, int nPosition)
{
	char	sParamName [64] ;
	char	sCountParamName [64] ;
	char	sLastParamName [64] ;
	char	sValue [64] ;
	int		nInsertPosition ;

	sprintf (sCountParamName, "{%s_count}", Param_List) ;
	if (nPosition > atoi (lr_eval_string (sCountParamName)))
	{
		nInsertPosition = atoi (lr_eval_string (sCountParamName)) + 1 ;

		sprintf (sCountParamName, "%s_count", Param_List) ;
		sprintf (sValue, "%d", nInsertPosition) ;
		lr_save_string (sValue, sCountParamName) ;
	}
    	else
		nInsertPosition = nPosition ;

	sprintf (sParamName, "%s_%d", Param_List, nInsertPosition) ;
	sprintf (sLastParamName, "{%s}", Param_To_Add) ;
	
	lr_save_string (lr_eval_string (sLastParamName), sParamName) ;
}

void Init_QC ()
{
	char	*pRunning_Host;
	char	*sPingAttr = lr_get_attrib_string("Ping") ;

	 


	pcoe_get_attrib_string ("DisableGroup", "False", "DisableGroup", "False") ;
	if (!stricmp ( lr_eval_string("{DisableGroup}"), "True")) 
	{
		lr_abort () ;	
		return ;
	}

	if (sPingAttr) 
	{
		if (stricmp (sPingAttr, "disable") == 0)
			bPingEnable = 0 ;
	}
	
	Init_Parameters () ;
	
	ci_load_dll(ci_this_context,("\\\\mydstore0001\\HPSWLABS\\ALM\\PCoE\\QC\\Apollo\\lib\\FreqParser.dll")) ;
 	ci_load_dll(ci_this_context,("\\\\mydstore0001\\HPSWLABS\\ALM\\PCoE\\QC\\Apollo\\lib\\MultyThreadPingToQC.dll")) ;
 	
	web_set_max_html_param_len("102400");

	 


    	pRunning_Host = lr_get_host_name();
	lr_save_string(pRunning_Host,"Running_Host");

	lr_start_transaction("Global_02_Login");

	web_reg_save_param("Login_Session_ID",
				"LB=LOGIN_SESSION_ID:",
				"RB=,\r\n",
				"LAST");
		
	web_reg_save_param("Login_Session_Key",
				"LB/ALNUMIC=LOGIN_SESSION_KEY:\\^^^^^^^^\\",
				"RB=,\r\n",
				"LAST");
	qc_custom_request("TDAPI_GeneralWebTreatment_2", 
		"URL={ServerName}/servlet/tdservlet/TDAPI_GeneralWebTreatment", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t45.inf", 
		"Mode=HTTP", 
		"EncType=text/html; charset=UTF-8", 
		"Body="
			"{\r\n"
				"0: \"0:conststr:Login\",\r\n"
				"1: \\0000002F\\0:conststr:0C4739AB-2E6A-47D5-8E5A-9E007F2D9B42,\r\n"
				"2: \"0:int:2\",\r\n"
				"3: \"0:int:-1\",\r\n"
				"4: \"0:conststr:\",\r\n"
				"5: \"0:int:-1\",\r\n"
				"6: \\{Recalculate}\\0:conststr:"
			"{\r\n"
				"USER_NAME:{UserName},\r\n"
				"PASSWORD:,\r\n"
				"CLIENTTYPE:\\0000002a\\Application Lifecycle Management Client UI,\r\n"
				"RETRIEVE_ADDITIONAL_INFO:,\r\n"
				"OTA_VERSION:12.50,\r\n"
				"OTA_BUILD_NUMBER:{BuildNumber}\r\n"
			"}\r\n"
				",\r\n"
				"7: \\{Recalculate}\\0:conststr:{Running_Host},\r\n"
				"8: \"65536:str:0\",\r\n"
				"9: \"0:pint:0\",\r\n"
				"10: \"65536:str:0\",\r\n"
				"11: \"0:pint:0\",\r\n"
				"12: \"0:pint:0\"\r\n"
			"}\r\n"
				"", 
		"LAST");				

	lr_output_message ("Run ping mechanism = %d", bPingEnable) ;
	
	if (bPingEnable)
	{
		pintPingThread = (int *)StartPingToServer ( lr_eval_string ("{ServerName}/servlet/tdservlet/TDAPI_GeneralWebTreatment"),
				"",
				"Content-Type: text/html; charset=UTF-8\r\n", 
				lr_eval_string("{\r\n"
					"0: \\00000017\\0:conststr:PingToServer,\r\n"
					"1: \\0000002F\\0:conststr:5344144B-52A1-4E19-8832-68D1B2B93E92,\r\n"
					"2: \"0:int:0\",\r\n"
					"3: \"0:int:{Login_Session_ID}\",\r\n"
					"4: \\00000023\\0:conststr:{Login_Session_Key},\r\n"
					"5: \"0:int:-1\",\r\n"
					"6: \"0:int:0\",\r\n"
					"7: \"65536:str:0\"\r\n"
					"}\r\n"),
					290
				) ;		
	}

	lr_end_transaction("Global_02_Login",2);

	 
	Select_Project ("Project", "MASTERDB", "") ;

	lr_start_transaction("Global_03_ConnectProject");

	web_reg_save_param("Project_Session_ID",
				"LB=PROJECT_SESSION_ID:",
				"RB=,\r\n",
				"LAST");
		
	web_reg_save_param("DB_PATH",
				"LB=DBPATH:",
				"RB=,\r\n",
				"SaveOffset=10",
				"LAST");

	qc_custom_request("TDAPI_GeneralWebTreatment_4", 
		"URL={ServerName}/servlet/tdservlet/TDAPI_GeneralWebTreatment", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t47.inf", 
		"Mode=HTTP", 
		"EncType=text/html; charset=UTF-8", 
		"Body="
			"{\r\n"
				"0: \\00000019\\0:conststr:ConnectProject,\r\n"
				"1: \\0000002F\\0:conststr:0884ABD2-1928-4390-8FF5-D61F565A93DD,\r\n"
				"2: \"0:int:3\",\r\n"
				"3: \"0:int:{Login_Session_ID}\",\r\n"
				"4: \\{Recalculate}\\0:conststr:{Login_Session_Key},\r\n"
				"5: \"0:int:-1\",\r\n"
				"6: \\{Recalculate}\\0:conststr:{\r\n"
				"DOMAIN_NAME:{Domain},\r\n"
			 
				"PROJECT_NAME:MASTERDB1\r\n}\r\n,\r\n"
				"7: \"65536:str:0\",\r\n"
				"8: \"0:pint:0\"\r\n"
			"}\r\n", 
		"LAST");

lr_start_transaction("Global_04_GetCustomization");
	qc_custom_request("TDAPI_GeneralWebTreatment_5", 
		"URL={ServerName}/servlet/tdservlet/TDAPI_GeneralWebTreatment", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t48.inf", 
		"Mode=HTTP", 
		"EncType=text/html; charset=UTF-8", 
		"Body="
			"{\r\n"
				"0: \\00000026\\0:conststr:GetProjectCustomizationData,\r\n"
				"1: \\0000002F\\0:conststr:4602A9C5-9457-41D4-B611-9AC285F6E9B1,\r\n"
				"2: \"0:int:4\",\r\n"
				"3: \"0:int:{Login_Session_ID}\",\r\n"
				"4: \\00000023\\0:conststr:{Login_Session_Key},\r\n"
				"5: \"0:int:{Project_Session_ID}\",\r\n"
				"6: \\00000140\\0:conststr:"
				"{\r\n"
				"Relations:@$@,\r\n"
				"Actions:@$@,\r\n"
				"Types:@$@,\r\n"
				"Modules:@$@,\r\n"
				"KPITypes:@$@,\r\n"
				"EntityAttributes:@$@,\r\n"
				"ReportProjectTemplates:@$@,\r\n"
				"Tables:@$@,\r\n"
				"TransitionsRules:@$@,\r\n"
				"Users:@$@,\r\n"
				"BusinessViews:@$@,\r\n"
				"Fields:@$@,\r\n"
				"BreakdownTypes:@$@,\r\n"
				"Lists:@$@,\r\n"
				"RBT:@$@,\r\n"
				"MailConditions:@$@,\r\n"
				"Groups:@$@,\r\n"
				"EntitiesMetadata:@$@\r\n"
				"}\r\n"
				",\r\n"
				"7: \"65536:str:0\"\r\n"
			"}\r\n", 
		"LAST");

		lr_end_transaction("Global_04_GetCustomization",2);
		
	qc_custom_request("TDAPI_GeneralWebTreatment_6", 
		"URL={ServerName}/servlet/tdservlet/TDAPI_GeneralWebTreatment", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t49.inf", 
		"Mode=HTTP", 
		"EncType=text/html; charset=UTF-8", 
		"Body="
			"{\r\n"
				"0: \\00000019\\0:conststr:GetByCodeValue,\r\n"
				"1: \\0000002F\\0:conststr:237D75FB-F068-4360-BB0B-339922CBCD1B,\r\n"
				"2: \"0:int:5\",\r\n"
				"3: \"0:int:{Login_Session_ID}\",\r\n"
				"4: \\00000023\\0:conststr:{Login_Session_Key},\r\n"
				"5: \"0:int:{Project_Session_ID}\",\r\n"
				"6: \\000009D8\\0:conststr:"
			"{\r\n"
				"SF_REFERENCE_TABLE:\\00000011\\BPM_ELEMENT_TYPES,\r\n"
				"SF_REFERENCE_NAME_COLUMN:BPMET_TYPE_NAME,\r\n"
				"SF_REFERENCE_ID_COLUMN:BPMET_ID\r\n"
			"}\r\n"
			"{\r\n"
				"SF_REFERENCE_TABLE:\\00000012\\BPTA_CHANGE_STATUS,\r\n"
				"SF_REFERENCE_NAME_COLUMN:\\00000017\\BPTA_CHANGE_STATUS_NAME,\r\n"
				"SF_REFERENCE_ID_COLUMN:\\00000015\\BPTA_CHANGE_STATUS_ID\r\n"
			"}\r\n"
			"{\r\n"
				"SF_REFERENCE_TABLE:BUILD,\r\n"
				"SF_REFERENCE_NAME_COLUMN:BI_ID,\r\n"
				"SF_REFERENCE_ID_COLUMN:BI_ID\r\n"
			"}\r\n"
			"{\r\n"
				"SF_REFERENCE_TABLE:CHANGESET,\r\n"
				"SF_REFERENCE_NAME_COLUMN:CHS_ID,\r\n"
				"SF_REFERENCE_ID_COLUMN:CHS_ID\r\n"
			"}\r\n"
			"{\r\n"
				"SF_REFERENCE_TABLE:LAB_ADAM_SERVERS,\r\n"
				"SF_REFERENCE_NAME_COLUMN:LAS_NAME,\r\n"
				"SF_REFERENCE_ID_COLUMN:LAS_ID\r\n"
			"}\r\n"
			"{\r\n"
				"SF_REFERENCE_TABLE:\\00000012\\LAB_AUT_HOST_POOLS,\r\n"
				"SF_REFERENCE_NAME_COLUMN:AUTPOOL_NAME,\r\n"
				"SF_REFERENCE_ID_COLUMN:AUTPOOL_ID\r\n"
			"}\r\n"
			"{\r\n"
				"SF_REFERENCE_TABLE:LAB_AUT_HOSTS,\r\n"
				"SF_REFERENCE_NAME_COLUMN:AUTHOST_NAME,\r\n"
				"SF_REFERENCE_ID_COLUMN:AUTHOST_ID\r\n"
			"}\r\n"
			"{\r\n"
				"SF_REFERENCE_TABLE:\\00000017\\LAB_DIAGNOSTICS_SERVERS,\r\n"
				"SF_REFERENCE_NAME_COLUMN:DIAG_SVR_NAME,\r\n"
				"SF_REFERENCE_ID_COLUMN:DIAG_SVR_ID\r\n"
			"}\r\n"
			"{\r\n"
				"SF_REFERENCE_TABLE:\\00000012\\LAB_HOST_LOCATIONS,\r\n"
				"SF_REFERENCE_NAME_COLUMN:LOC_NAME,\r\n"
				"SF_REFERENCE_ID_COLUMN:LOC_ID\r\n"
			"}\r\n"
			"{\r\n"
				"SF_REFERENCE_TABLE:LAB_HOST_POOLS,\r\n"
				"SF_REFERENCE_NAME_COLUMN:POOL_NAME,\r\n"
				"SF_REFERENCE_ID_COLUMN:POOL_ID\r\n"
			"}\r\n"
			"{\r\n"
				"SF_REFERENCE_TABLE:LAB_HOSTS,\r\n"
				"SF_REFERENCE_NAME_COLUMN:HOST_NAME,\r\n"
				"SF_REFERENCE_ID_COLUMN:HOST_ID\r\n"
			"}\r\n"
			"{\r\n"
				"SF_REFERENCE_TABLE:LAB_MILISTENERS,\r\n"
				"SF_REFERENCE_NAME_COLUMN:MIL_NAME,\r\n"
				"SF_REFERENCE_ID_COLUMN:MIL_ID\r\n"
			"}\r\n"
			"{\r\n"
				"SF_REFERENCE_TABLE:REQ_TYPE,\r\n"
				"SF_REFERENCE_NAME_COLUMN:TPR_NAME,\r\n"
				"SF_REFERENCE_ID_COLUMN:TPR_TYPE_ID\r\n"
			"}\r\n"
			"{\r\n"
				"SF_REFERENCE_TABLE:SERVICE_ASPECT,\r\n"
				"SF_REFERENCE_NAME_COLUMN:SA_NAME,\r\n"
				"SF_REFERENCE_ID_COLUMN:SA_ID\r\n"
			"}\r\n"
			"{\r\n"
				"SF_REFERENCE_TABLE:\\00000016\\SOA_APP_COMPONENT_TYPE,\r\n"
				"SF_REFERENCE_NAME_COLUMN:ACT_NAME,\r\n"
				"SF_REFERENCE_ID_COLUMN:ACT_ID\r\n"
			"}\r\n"
			"{\r\n"
				"SF_REFERENCE_TABLE:\\00000011\\SSE_APP_PARAM_SET,\r\n"
				"SF_REFERENCE_NAME_COLUMN:APS_NAME,\r\n"
				"SF_REFERENCE_ID_COLUMN:APS_ID\r\n"
			"}\r\n"
			"{\r\n"
				"SF_REFERENCE_TABLE:\\00000017\\SSE_APP_PARAM_VALUE_SET,\r\n"
				"SF_REFERENCE_NAME_COLUMN:APVS_NAME,\r\n"
				"SF_REFERENCE_ID_COLUMN:APVS_ID\r\n"
			"}\r\n"
			"{\r\n"
				"SF_REFERENCE_TABLE:SSE_APPPARAM,\r\n"
				"SF_REFERENCE_NAME_COLUMN:APPPARAM_NAME,\r\n"
				"SF_REFERENCE_ID_COLUMN:APPPARAM_ID\r\n"
			"}\r\n"
			"{\r\n"
				"SF_REFERENCE_TABLE:SSE_PROCEDURES,\r\n"
				"SF_REFERENCE_NAME_COLUMN:PRC_NAME,\r\n"
				"SF_REFERENCE_ID_COLUMN:PRC_ID\r\n"
			"}\r\n"
			"{\r\n"
				"SF_REFERENCE_TABLE:TASK_LOG_TYPE,\r\n"
				"SF_REFERENCE_NAME_COLUMN:TASKL_TYPE_NAME,\r\n"
				"SF_REFERENCE_ID_COLUMN:TASKL_TYPE_ID\r\n"
			"}\r\n"
			"{\r\n"
				"SF_REFERENCE_TABLE:TASK_STATE,\r\n"
				"SF_REFERENCE_NAME_COLUMN:TASK_STATE_NAME,\r\n"
				"SF_REFERENCE_ID_COLUMN:TASK_STATE_ID\r\n"
			"}\r\n"
				",\r\n"
				"7: \"65536:str:0\"\r\n"
			"}\r\n", 
		"LAST");

	qc_custom_request("TDAPI_GeneralWebTreatment_7", 
		"URL={ServerName}/servlet/tdservlet/TDAPI_GeneralWebTreatment", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t50.inf", 
		"Mode=HTTP", 
		"EncType=text/html; charset=UTF-8", 
		"Body="
			"{\r\n"
				"0: \\0000001E\\0:conststr:ListRepositoryFiles,\r\n"
				"1: \\0000002F\\0:conststr:69EABAB5-04AF-48F9-B9E1-B73A50AAA430,\r\n"
				"2: \"0:int:6\",\r\n"
			    "3: \"0:int:{Login_Session_ID}\",\r\n"
			    "4: \\00000023\\0:conststr:{Login_Session_Key},\r\n"
			    "5: \"0:int:{Project_Session_ID}\",\r\n"
				"6: \\{Recalculate}\\0:conststr:"
			"{\r\n"
				"ROOT:\\{Recalculate}\\{DB_PATH}\\scripts,\r\n"
				"FILTER_CLIENT:\\000001f7\\<.\\extcmds.tdu>,<.\\Template_extcmds.tdu>,<.\\common.tds>,<.\\req.tds>,<.\\testplan.tds>,<.\\testlab.tds>,"
				"<.\\manrun.tds>,<.\\defects.tds>,<.\\component.tds>,<.\\management.tds>,<.\\resources.tds>,<.\\analysis.tds>,<.\\extensions.tds>,<.\\Template_common.tds>,<.\\Template_req.tds>,<.\\Template_testplan.tds>,<.\\Template_testlab.tds>,<.\\Template_manrun.tds>,<.\\Template_defects.tds>,<.\\Template_component.tds>,<.\\Template_management.tds>,<.\\Template_resources.tds>,<.\\Template_analysis.tds>,<.\\Template_extensions.tds>,\r\n"
				"FILTER_SERVER:\\000001f7\\<.\\extcmds.tdu>,<.\\Template_extcmds.tdu>,"
				"<.\\common.tds>,<.\\req.tds>,<.\\testplan.tds>,<.\\testlab.tds>,<.\\manrun.tds>,<.\\defects.tds>,<.\\component.tds>,<.\\management.tds>,<.\\resources.tds>,<.\\analysis.tds>,<.\\extensions.tds>,<.\\Template_common.tds>,<.\\Template_req.tds>,<.\\Template_testplan.tds>,<.\\Template_testlab.tds>,<.\\Template_manrun.tds>,<.\\Template_defects.tds>,<.\\Template_component.tds>,<.\\Template_management.tds>,<.\\Template_resources.tds>,<.\\Template_analysis.tds>,<.\\Template_extensions.tds>,\r\n"
				"UNCERTAIN_CLIENT_FILTERS:\\00000018\\111111111111111111111111\r\n"
			"}\r\n"
				",\r\n"
				"7: \"65536:str:0\"\r\n"
			"}\r\n", 
		"LAST");


	lr_end_transaction("Global_03_ConnectProject",2);

	 
}

void Exit_QC ()
{
	
	lr_start_transaction("Global_04_DisconnectProject");

	qc_custom_request("TDAPI_GeneralWebTreatment_15", 
		"URL={ServerName}/servlet/tdservlet/TDAPI_GeneralWebTreatment", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		"EncType=text/html; charset=UTF-8", 
		"Body="
			"{\r\n"
				"0: \\0000001C\\0:conststr:DisconnectProject,\r\n"
				"1: \\0000002F\\0:conststr:C51EAE3B-B1B4-4465-A67C-7E859BCF783A,\r\n"
				"2: \"0:int:11\",\r\n"
			    "3: \"0:int:{Login_Session_ID}\",\r\n"
			    "4: \\00000023\\0:conststr:{Login_Session_Key},\r\n"
			    "5: \"0:int:{Project_Session_ID}\"\r\n"
			"}\r\n"
				"", 
		"LAST");

	lr_end_transaction("Global_04_DisconnectProject",2);
	
	lr_start_transaction("Global_05_Logout");

	qc_custom_request("TDAPI_GeneralWebTreatment_16", 
		"URL={ServerName}/servlet/tdservlet/TDAPI_GeneralWebTreatment", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		"EncType=text/html; charset=UTF-8", 
		"Body="
			"{\r\n"
				"0: \\00000011\\0:conststr:Logout,\r\n"
				"1: \\0000002F\\0:conststr:25D63DA6-9E63-4160-AB30-539F21DFE99E,\r\n"
				"2: \"0:int:12\",\r\n"
			    "3: \"0:int:{Login_Session_ID}\",\r\n"
			    "4: \\00000023\\0:conststr:{Login_Session_Key},\r\n"
				"5: \"0:int:-1\"\r\n"
			"}\r\n"
				"", 
		"LAST");
		
	lr_end_transaction("Global_05_Logout",2);

	if (bPingEnable)
	{	
 
		StopPingToServer(pintPingThread);
	}

}
# 17 "globals.h" 2






# 3 "c:\\users\\stepanvl.hpeswlab\\appdata\\local\\temp\\8\\td_80\\12.53.0.0_952\\9387d090\\test\\208\\208\\1003\\\\combined_1003.c" 2

# 1 "vuser_init.c" 1
vuser_init()
{

	Init_QC ();


	return 0;
}
# 4 "c:\\users\\stepanvl.hpeswlab\\appdata\\local\\temp\\8\\td_80\\12.53.0.0_952\\9387d090\\test\\208\\208\\1003\\\\combined_1003.c" 2

# 1 "Action.c" 1
Action()
{

	

	lr_start_transaction("ConcurrentUser_GetBug");


	qc_custom_request("TDAPI_GeneralWebTreatment_18", 
        "URL={ServerName}/servlet/tdservlet/TDAPI_GeneralWebTreatment", 
        "Method=POST", 
        "Resource=0", 
        "RecContentType=application/octet-stream", 
        "Referer=", 
        "Snapshot=t18.inf", 
        "Mode=HTML", 
        "EncType=text/html; charset=UTF-8", 
        "Body="
            "{\r\n"
                "0: \\00000016\\0:conststr:GetBugValue,\r\n"
                "1: \\0000002F\\0:conststr:{Guid8rnd}-5C8B-4717-887E-{Guid12rnd},\r\n"
                "2: \"0:int:16\",\r\n"
                "3: \"0:int:{Login_Session_ID}\",\r\n"
                "4: \\{Recalculate}\\0:conststr:{Login_Session_Key},\r\n"
                "5: \"0:int:{Project_Session_ID}\",\r\n"
                "6: \\000002F7\\0:conststr:"
            "{\r\n"
                "FETCH_LIMIT:500,\r\n"
                "IDS:\"[Filter]\r\n\",\r\n"
                "FIELDS:\\00000266\\BG_ACTUAL_FIX_TIME,BG_ATTACHMENT,BG_BUG_ID,BG_BUG_VER_STAMP,BG_CLOSING_DATE,BG_CLOSING_VERSION,BG_CYCLE_ID,BG_CYCLE_REFERENCE,BG_DESCRIPTION,BG_DETECTED_BY,"
        "BG_DETECTED_IN_RCYC,BG_DETECTED_IN_REL,BG_DETECTION_DATE,BG_DETECTION_VERSION,BG_DEV_COMMENTS,BG_ESTIMATED_FIX_TIME,BG_EXTENDED_REFERENCE,BG_HAS_CHANGE,BG_PLANNED_CLOSING_VER,BG_PRIORITY,BG_PROJECT,BG_REPRODUCIBLE,BG_REQUEST_ID,BG_REQUEST_NOTE,BG_REQUEST_SERVER,BG_REQUEST_TYPE,BG_RESPONSIBLE,BG_RUN_REFERENCE,BG_SEVERITY,BG_STATUS,BG_STEP_REFERENCE,BG_SUBJECT,BG_SUMMARY,BG_TARGET_RCYC,BG_TARGET_REL,BG_TEST_REFERENCE,BG_TO_MAIL,BG_USER_01,BG_USER_02,BG_VTS,\r\n"
                "LIMIT:30,\r\n"
                "HAS_LINKAGE:,\r\n"
                ""
        "HAS_OTHERS_LINKAGE:,\r\n"
                "INCLUDE_RELATED_DATA:\r\n"
            "}\r\n"
                ",\r\n"
                "7: \"65536:str:0\"\r\n"
            "}\r\n"
                "", 
        "LAST");

	

	lr_end_transaction("ConcurrentUser_GetBug",2);


	
}
# 5 "c:\\users\\stepanvl.hpeswlab\\appdata\\local\\temp\\8\\td_80\\12.53.0.0_952\\9387d090\\test\\208\\208\\1003\\\\combined_1003.c" 2

# 1 "vuser_end.c" 1
vuser_end()
{

	Exit_QC ();

	return 0;
}
# 6 "c:\\users\\stepanvl.hpeswlab\\appdata\\local\\temp\\8\\td_80\\12.53.0.0_952\\9387d090\\test\\208\\208\\1003\\\\combined_1003.c" 2

