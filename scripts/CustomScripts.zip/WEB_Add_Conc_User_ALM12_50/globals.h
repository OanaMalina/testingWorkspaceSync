#ifndef _GLOBALS_H 
#define _GLOBALS_H

long startTime, curTime;
int SleepTime, ReportTime;

//--------------------------------------------------------------------
// Include Files
#include "lrun.h"
#include "web_api.h"
#include "lrw_custom_body.h"

//--------------------------------------------------------------------
// Global Variables

#include "\\mydstore0001\HPSWLABS\ALM\PCoE\QC\Apollo\Include\FrecParcer.h"
#include "\\mydstore0001\HPSWLABS\ALM\PCoE\QC\Apollo\Include\Initialize_QC_ALM1250_fix.h"
#include "\\mydstore0001\HPSWLABS\ALM\PCoE\QC\Apollo\Include\Utils.h"


#endif // _GLOBALS_H

