vuser_init()
{

	Init_QC ();


	return 0;
}
