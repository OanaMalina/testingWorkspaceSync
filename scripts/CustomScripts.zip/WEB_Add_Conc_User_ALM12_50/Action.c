Action()
{

	

	lr_start_transaction("ConcurrentUser_GetBug");


	web_custom_request("TDAPI_GeneralWebTreatment_18", 
        "URL={ServerName}/servlet/tdservlet/TDAPI_GeneralWebTreatment", 
        "Method=POST", 
        "Resource=0", 
        "RecContentType=application/octet-stream", 
        "Referer=", 
        "Snapshot=t18.inf", 
        "Mode=HTML", 
        "EncType=text/html; charset=UTF-8", 
        "Body="
            "{\r\n"
                "0: \\00000016\\0:conststr:GetBugValue,\r\n"
                "1: \\0000002F\\0:conststr:{Guid8rnd}-5C8B-4717-887E-{Guid12rnd},\r\n"
                "2: \"0:int:16\",\r\n"
                "3: \"0:int:{Login_Session_ID}\",\r\n"
                "4: \\{Recalculate}\\0:conststr:{Login_Session_Key},\r\n"
                "5: \"0:int:{Project_Session_ID}\",\r\n"
                "6: \\000002F7\\0:conststr:"
            "{\r\n"
                "FETCH_LIMIT:500,\r\n"
                "IDS:\"[Filter]\r\n\",\r\n"
                "FIELDS:\\00000266\\BG_ACTUAL_FIX_TIME,BG_ATTACHMENT,BG_BUG_ID,BG_BUG_VER_STAMP,BG_CLOSING_DATE,BG_CLOSING_VERSION,BG_CYCLE_ID,BG_CYCLE_REFERENCE,BG_DESCRIPTION,BG_DETECTED_BY,"
        "BG_DETECTED_IN_RCYC,BG_DETECTED_IN_REL,BG_DETECTION_DATE,BG_DETECTION_VERSION,BG_DEV_COMMENTS,BG_ESTIMATED_FIX_TIME,BG_EXTENDED_REFERENCE,BG_HAS_CHANGE,BG_PLANNED_CLOSING_VER,BG_PRIORITY,BG_PROJECT,BG_REPRODUCIBLE,BG_REQUEST_ID,BG_REQUEST_NOTE,BG_REQUEST_SERVER,BG_REQUEST_TYPE,BG_RESPONSIBLE,BG_RUN_REFERENCE,BG_SEVERITY,BG_STATUS,BG_STEP_REFERENCE,BG_SUBJECT,BG_SUMMARY,BG_TARGET_RCYC,BG_TARGET_REL,BG_TEST_REFERENCE,BG_TO_MAIL,BG_USER_01,BG_USER_02,BG_VTS,\r\n"
                "LIMIT:30,\r\n"
                "HAS_LINKAGE:,\r\n"
                ""
        "HAS_OTHERS_LINKAGE:,\r\n"
                "INCLUDE_RELATED_DATA:\r\n"
            "}\r\n"
                ",\r\n"
                "7: \"65536:str:0\"\r\n"
            "}\r\n"
                "", 
        LAST);

	

	lr_end_transaction("ConcurrentUser_GetBug",LR_AUTO);


	
}
