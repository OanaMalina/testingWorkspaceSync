//---------------------------------------------
//Script Title        :
//Script Description  :
//
//
//Recorder Version    : 1982
//---------------------------------------------

namespace Script {
    using LoadRunner;
    using Mercury.LoadRunner.DotNetProtocol.Replay;
    using System;
    using TDAPIOLELib;

    public partial class VuserClass {
        
        public virtual int Action() {
            int bugID;
            lr.think_time(10);
            bugID = addDefect();
            if (lr.eval_int("{iterationNum}")%4==0) {
                lr.think_time(10);
                updateDefect(bugID);
            }
            lr.think_time(10);
            deleteDefect(bugID);

            return 0;
        }

        public int addDefect() {
            IBugFactory ibugfact;
            IBug ibug;
            String strFieldName;
            String strFieldData;

            ibugfact = tdconnection.BugFactory;
            ibug = ibugfact.AddItem(DBNull.Value);

            for (int i = 0; i < lr.eval_int("{sCount}"); i++) {
                strFieldName = lr.eval_string("{Label}");
                if (strFieldName.Contains("DATE"))
                {
                    ibug[strFieldName] = DateTime.Now;
                }
                else {
                    strFieldData = lr.eval_string("{sData}");
                    String[] datalist = strFieldData.Split(';');
                    int pos = rnd.Next(0, datalist.Length);
                    strFieldData = datalist[pos];
                    ibug[strFieldName] = strFieldData;
                }

            }

            strCurrentOpenTransactionName = "DEF_CreateDeleteDefect_T01_AddDefect";
            lr.start_transaction(strCurrentOpenTransactionName);
            ibug.Post();
            if (ibug.ID > 0)
            {
                lr.end_transaction(strCurrentOpenTransactionName, lr.PASS);
            }
            else {
                lr.end_transaction(strCurrentOpenTransactionName, lr.FAIL);
            }

            return ibug.ID;
        }

        public void updateDefect(int bugid) {
            IBugFactory ibugfact;
            IBug ibug;

            ibugfact = tdconnection.BugFactory;
            ibug = ibugfact[bugid];

            ibug["BG_USER_01"] = lr.eval_string("{Value1}");

            strCurrentOpenTransactionName = "DEF_CreateDeleteDefect_T02_UpdateDefect";
            lr.start_transaction(strCurrentOpenTransactionName);
            ibug.Post();
            lr.end_transaction(strCurrentOpenTransactionName, lr.AUTO);

        }


        public void deleteDefect(int bugid) {
            IBugFactory ibugfact;
            ibugfact = tdconnection.BugFactory;
            strCurrentOpenTransactionName = "DEF_CreateDeleteDefect_T03_DeleteDefect";
            lr.start_transaction(strCurrentOpenTransactionName);
            ibugfact.RemoveItem(bugid);
            lr.end_transaction(strCurrentOpenTransactionName, lr.AUTO);

        }

    }
}
