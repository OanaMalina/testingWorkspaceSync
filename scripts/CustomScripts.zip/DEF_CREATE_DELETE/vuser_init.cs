//---------------------------------------------
//Script Title        :
//Script Description  :
//
//
//Recorder Version    : 
//---------------------------------------------

namespace Script
{
    using TDAPIOLELib;
    using System;
    public partial class VuserClass
    {
        string strCurrentOpenTransactionName;
        public int vuser_init()
        {

            //Create tdconnection
            tdconnection = new TDConnection();
            setAttributes();
            selectProject();
            selectUserName();
           
            strCurrentOpenTransactionName = "T01_Login_PASSWORD";
            lr.start_transaction(strCurrentOpenTransactionName);
            tdconnection.InitConnectionEx(getAttribute("ServerName"));
            tdconnection.Login(getAttribute("UserName"), getAttribute("Password"));
            lr.end_transaction(strCurrentOpenTransactionName, lr.AUTO);

            strCurrentOpenTransactionName = "T02_Connect_Project";
	    	lr.start_transaction(strCurrentOpenTransactionName);
	    	tdconnection.Connect(getAttribute("Domain"),getAttribute("Project"));
	    	//tdconnection.Connect(getAttribute("ServerDomain"),getAttribute("Project"));
	    	lr.end_transaction(strCurrentOpenTransactionName,lr.AUTO);
		    
			return 0;
        }
    }
}

