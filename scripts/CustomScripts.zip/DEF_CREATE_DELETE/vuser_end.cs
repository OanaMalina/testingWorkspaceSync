//---------------------------------------------
//Script Title        :
//Script Description  :
//
//
//Recorder Version    : 
//---------------------------------------------

namespace Script
{
    public partial class VuserClass
    {
        public int vuser_end()
        {        	
        	if (tdconnection.Connected){
        		strCurrentOpenTransactionName = "T03_DisconnectProject";
        		lr.start_transaction(strCurrentOpenTransactionName);
        		tdconnection.DisconnectProject();
        		tdconnection.ReleaseConnection();
        		lr.end_transaction(strCurrentOpenTransactionName,lr.AUTO);
        	}
        	
            return 0;
        }
    }
}
