char *CLNumOfTrans;
char *CLTimeout;
char *CLThroughput;
char *CLThinkTime;

vuser_init()
{
	//test comment
	CLNumOfTrans=lr_get_attrib_string("transactionNum"); 
	if (CLNumOfTrans==NULL){ 
		lr_error_message("***Failed to get transactionNum, Unknown transactionNum. \n"); 
		CLNumOfTrans = "3";
		lr_output_message("CLNumOfTrans was assigned %s", CLNumOfTrans);
		//return(0); 
	}
	else lr_output_message("CLNumOfTrans is %s", CLNumOfTrans);

	CLTimeout = lr_get_attrib_string("timeout"); 
	if (CLTimeout==NULL){ 

		lr_error_message("***Failed to get timeout. Unknown timeout.\n"); 
		CLTimeout = "20";
		lr_output_message("CLTimeout was assigned %s", CLTimeout);

		//return(0); 
	}
	else lr_output_message("CLTimeout is %s", CLTimeout);

	CLThinkTime=lr_get_attrib_string("thinkTime"); 
	if (CLThinkTime==NULL){ 

		lr_error_message("***Failed to get Think time. Unknown think time.\n"); 
		CLThinkTime = "20";
		lr_output_message("CLThinkTime was assigned %s", CLThinkTime);

		//return(0); 
	}
	else lr_output_message("CLThinkTime is %s", CLThinkTime);


	CLThroughput = lr_get_attrib_string("throughput"); 
	if (CLThroughput==NULL){ 

		lr_error_message("***Failed to get Throughput. Unknown.\n"); 
		CLThroughput="5";
		lr_output_message("CLThroughput was assigned %s", CLThroughput);
		//return(0); 
	}
	else lr_output_message("CLThroughput is %s", CLThroughput);

	return 0;
}
