Action()
{
	int num; 

	if (atoi(CLNumOfTrans)==0) 
	{
		lr_start_transaction(lr_eval_string("{runTimeGroupName}"));
		lr_user_data_point("HTTP_200", 1); //simulate hits
		lr_user_data_point("mic_recv", atoi(CLThroughput)*1024); //simulate throuput
		sleep(1000*atoi(CLTimeout));
		lr_set_transaction_status(LR_PASS);
		lr_end_transaction(lr_eval_string("{runTimeGroupName}"),LR_AUTO);
		lr_think_time(atoi(CLThinkTime));
	}
	else
	{
		for (num = 1; num <= atoi(CLNumOfTrans); num++) 
		{
			//lr_vuser_status_message( lr_eval_string("Iteration {runTimeIterationCount} creating transaction name 'transaction%d'"), num);
			lr_save_int(num,"tNumber");
			if (num < 10) 
			{
				lr_start_transaction(lr_eval_string("{runTimeGroupName}_000{tNumber}"));
			}
			else
			{
				if (num < 100) 
				{
					lr_start_transaction(lr_eval_string("{runTimeGroupName}_00{tNumber}"));
				}
				else
				{
					if (num < 1000) 
					{
						lr_start_transaction(lr_eval_string("{runTimeGroupName}_0{tNumber}"));
					}
					else
					{
						lr_start_transaction(lr_eval_string("{runTimeGroupName}_{tNumber}"));
					}
				}
			}	
			lr_set_transaction_status(LR_PASS);
			lr_user_data_point("HTTP_200", 1); //simulate hits
			lr_user_data_point("mic_recv", atoi(CLThroughput)*1024); //simulate throuput
			sleep(1000*atoi(CLTimeout));
			if (num < 10) 
			{
				lr_end_transaction(lr_eval_string("{runTimeGroupName}_000{tNumber}"), LR_AUTO);
			}
			else
			{
				if (num < 100) 
				{
					lr_end_transaction(lr_eval_string("{runTimeGroupName}_00{tNumber}"), LR_AUTO);
				}
				else
				{
					if (num < 1000) 
					{
						lr_end_transaction(lr_eval_string("{runTimeGroupName}_0{tNumber}"), LR_AUTO);
					}
					else
					{
						lr_end_transaction(lr_eval_string("{runTimeGroupName}_{tNumber}"), LR_AUTO);
					}
					
				}
			}
			lr_think_time(atoi(CLThinkTime));
		}
	}
	return 0;
}
